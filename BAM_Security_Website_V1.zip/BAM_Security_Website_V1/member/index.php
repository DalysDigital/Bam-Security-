<?php
require_once __DIR__.'/../config/config.php';member_required();
$s=db()->prepare('SELECT * FROM members WHERE id=?');$s->execute([$_SESSION['member_id']]);$m=$s->fetch();if(!$m){session_destroy();redirect('login.php');}
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>My BAM ID</title><link rel="stylesheet" href="../assets/style.css"></head><body>
<header class="topbar"><div class="container nav"><a class="brand" href="../"><img src="../assets/bam-logo.png"></a><nav><a href="../">Website</a><a href="logout.php">Logout</a></nav></div></header>
<div class="container"><h1>My BAM Digital ID</h1><div class="card" style="text-align:center"><img src="<?=e(member_photo($m['photo']))?>" style="width:130px;height:150px;object-fit:cover;border-radius:10px"><h2><?=e($m['name'])?></h2><p><?=e($m['designation'])?></p><p><b><?=e($m['member_no'])?></b></p><a class="btn btn-red" href="../id.php?id=<?=urlencode($m['member_no'])?>" target="_blank">Open / Print Digital ID</a></div></div></body></html>