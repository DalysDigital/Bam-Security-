<?php $base = $base ?? ''; $current = basename($_SERVER['PHP_SELF'] ?? 'index.php'); ?>
<div class="admin-header-tools" aria-label="Admin controls">
<button class="admin-app-icon" id="adminAppInstallButton" type="button" title="Install BAM Admin App" aria-label="Install BAM Admin App"><img src="../assets/icon-192.png" alt="BAM App"></button>
<button class="admin-theme-top" id="adminThemeToggle" type="button" title="Day / Night" aria-label="Switch Day / Night"><span id="adminThemeIcon">☾</span></button>
</div>
<nav class="admin-nav" id="adminNavPanel" aria-label="BAM Administration">
  <a class="<?= $current==='index.php'?'active':'' ?>" href="<?=$base?>index.php">Home</a>
  <a class="<?= $current==='members.php'?'active':'' ?>" href="<?=$base?>members.php">Members</a>
  <a class="<?= $current==='events.php'?'active':'' ?>" href="<?=$base?>events.php">Events</a>
  <a class="<?= $current==='invoices.php'?'active':'' ?>" href="<?=$base?>invoices.php">Invoices</a>
  <a class="<?= $current==='letters.php'?'active':'' ?>" href="<?=$base?>letters.php">Letters</a>
  <a class="<?= $current==='audit.php'?'active':'' ?>" href="<?=$base?>audit.php">Activity</a>
  <a class="<?= $current==='id_fields.php'?'active':'' ?>" href="<?=$base?>id_fields.php">ID Fields</a>
  <a class="<?= $current==='settings.php'?'active':'' ?>" href="<?=$base?>settings.php">Settings</a>
  <a class="<?= $current==='frontend.php'?'active':'' ?>" href="<?=$base?>frontend.php">Website Editor</a>
  <a class="<?= $current==='admins.php'?'active':'' ?>" href="<?=$base?>admins.php">Admins</a>
  <a class="admin-logout" href="<?=$base?>logout.php">Logout</a>
</nav>

<!-- Mobile: Instagram-style floating navigation. Desktop navigation above remains unchanged. -->
<nav class="admin-mobile-v57" aria-label="BAM mobile administration navigation">
  <a href="<?=$base?>index.php" class="v57-mobile-item <?= $current==='index.php'?'active':'' ?>"><span class="v57-icon">⌂</span><span>Home</span></a>
  <a href="<?=$base?>members.php" class="v57-mobile-item <?= $current==='members.php'?'active':'' ?>"><span class="v57-icon">♙</span><span>Members</span></a>
  <a href="<?=$base?>events.php" class="v57-mobile-item <?= $current==='events.php'?'active':'' ?>"><span class="v57-icon">▣</span><span>Events</span></a>
  <a href="<?=$base?>invoices.php" class="v57-mobile-item <?= $current==='invoices.php'?'active':'' ?>"><span class="v57-icon">▤</span><span>Invoices</span></a>
  <button type="button" class="v57-mobile-item <?= in_array($current,['letters.php','audit.php','id_fields.php','settings.php','frontend.php','admins.php'],true)?'active':'' ?>" id="v57MoreButton"><span class="v57-icon">☰</span><span>More</span></button>
</nav>

<div class="v57-more" id="v57More" aria-hidden="true">
  <div class="v57-more-backdrop" id="v57MoreBackdrop"></div>
  <div class="v57-more-sheet" role="dialog" aria-modal="true" aria-label="More administration options">
    <div class="v57-more-head"><strong>More</strong><button type="button" id="v57MoreClose" aria-label="Close">×</button></div>
    <div class="v57-more-grid">
      <a href="<?=$base?>letters.php"><span>✉</span>Letters</a>
      <a href="<?=$base?>audit.php"><span>◉</span>Activity</a>
      <a href="<?=$base?>id_fields.php"><span>▣</span>ID Fields</a>
      <a href="<?=$base?>settings.php"><span>⚙</span>Settings</a>
      <a href="<?=$base?>frontend.php"><span>✦</span>Website</a>
      <a href="<?=$base?>admins.php"><span>♙</span>Admins</a>
      <a class="v57-more-logout" href="<?=$base?>logout.php"><span>↪</span>Logout</a>
    </div>
  </div>
</div>
<script>
(function(){
  const root=document.documentElement;
  const themeBtn=document.getElementById('adminThemeToggle');
  const themeIcon=document.getElementById('adminThemeIcon');
  const applyTheme=mode=>{
    mode=mode==='day'?'day':'night'; root.dataset.adminTheme=mode; localStorage.setItem('bam-admin-theme',mode);
    const img=document.querySelector('.topbar .brand img'); if(img) img.src=mode==='day'?'../assets/bam-logo-day.png':'../assets/bam-logo.png';
    if(themeIcon) themeIcon.textContent=mode==='day'?'☀':'☾';
  };
  applyTheme(localStorage.getItem('bam-admin-theme')||root.dataset.adminTheme||'night');
  themeBtn?.addEventListener('click',()=>applyTheme(root.dataset.adminTheme==='day'?'night':'day'));
  window.bamAdminApplyTheme=applyTheme;

  const panel=document.getElementById('v57More'), more=document.getElementById('v57MoreButton'), close=document.getElementById('v57MoreClose'), backdrop=document.getElementById('v57MoreBackdrop');
  const closeMore=()=>{panel?.classList.remove('open');panel?.setAttribute('aria-hidden','true');document.body.classList.remove('v57-more-open');more?.setAttribute('aria-expanded','false');};
  const openMore=()=>{panel?.classList.add('open');panel?.setAttribute('aria-hidden','false');document.body.classList.add('v57-more-open');more?.setAttribute('aria-expanded','true');};
  more?.addEventListener('click',()=>panel?.classList.contains('open')?closeMore():openMore());
  close?.addEventListener('click',closeMore); backdrop?.addEventListener('click',closeMore);
  panel?.querySelectorAll('a').forEach(a=>a.addEventListener('click',closeMore));
  document.addEventListener('keydown',e=>{if(e.key==='Escape')closeMore();});
})();
</script>
