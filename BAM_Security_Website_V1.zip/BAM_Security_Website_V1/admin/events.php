<?php
require_once __DIR__.'/../config/config.php'; admin_required(); ensure_events_table();
$editId=(int)($_GET['edit']??0); $msg=''; $error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
  verify_csrf();
  $action=$_POST['action']??'save';
  try{
    if($action==='delete'){
      $id=(int)$_POST['id']; db()->prepare('DELETE FROM events WHERE id=?')->execute([$id]); audit('EVENT_DELETED'); redirect('events.php');
    }
    $id=(int)($_POST['id']??0);
    $data=[
      trim($_POST['event_name']??''),trim($_POST['event_type']??''),trim($_POST['client_name']??''),
      trim($_POST['location']??''),($_POST['event_date']??'')?:null,($_POST['start_time']??'')?:null,($_POST['end_time']??'')?:null,
      max(0,(int)($_POST['personnel_required']??0)),max(0,(int)($_POST['personnel_deployed']??0)),
      strtolower(trim($_POST['status']??'planned')),trim($_POST['notes']??'')
    ];
    if($data[0]==='') throw new RuntimeException('Event name is required.');
    if(!in_array($data[9],['planned','confirmed','ongoing','completed','cancelled'],true)) $data[9]='planned';
    if($id){
      $sql='UPDATE events SET event_name=?,event_type=?,client_name=?,location=?,event_date=?,start_time=?,end_time=?,personnel_required=?,personnel_deployed=?,status=?,notes=? WHERE id=?';
      $data[]=$id; db()->prepare($sql)->execute($data); audit('EVENT_UPDATED'); $msg='Event updated successfully.';
    }else{
      $sql='INSERT INTO events(event_name,event_type,client_name,location,event_date,start_time,end_time,personnel_required,personnel_deployed,status,notes) VALUES(?,?,?,?,?,?,?,?,?,?,?)';
      db()->prepare($sql)->execute($data); audit('EVENT_CREATED'); $msg='Event created successfully.';
    }
    $editId=$id;
  }catch(Throwable $e){$error=$e->getMessage();}
}
$editing=null;
if($editId){$s=db()->prepare('SELECT * FROM events WHERE id=?');$s->execute([$editId]);$editing=$s->fetch();}
$q=trim($_GET['q']??'');$status=strtolower(trim($_GET['status']??''));$where=[];$args=[];
if($q!==''){ $where[]='(event_name LIKE ? OR client_name LIKE ? OR location LIKE ?)';$args=["%$q%","%$q%","%$q%"]; }
if($status!==''){ $where[]='status=?';$args[]=$status; }
$sql='SELECT * FROM events'.($where?' WHERE '.implode(' AND ',$where):'').' ORDER BY event_date DESC,id DESC';
$st=db()->prepare($sql);$st->execute($args);$rows=$st->fetchAll();
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#060606"><title>BAM Events & Operations</title><link rel="stylesheet" href="../assets/admin.css?v=64"><link rel="manifest" href="/admin/manifest.json"><link rel="apple-touch-icon" href="/admin/apple-touch-icon.png"><script src="pwa.js?v=64" defer></script></head><body class="admin-page"><script>document.documentElement.dataset.adminTheme=<?=json_encode(get_setting('site_theme','night'))?>;</script>
<header class="topbar"><div class="container nav"><a class="brand" href="index.php"><img src="<?=get_setting('site_theme','night')==='day'?'../assets/bam-logo-day.png':'../assets/bam-logo.png'?>" alt="BAM"><strong style="letter-spacing:.14em;font-size:11px">BAM ADMIN</strong></a><?php $base=""; include __DIR__.'/_nav.php'; ?></div></header>
<main class="container">
<div style="margin-bottom:20px"><div style="font-size:9px;letter-spacing:.22em;color:#777;font-weight:900">BAM // FIELD OPERATIONS</div><h1>Events & Operations</h1><p class="muted">Record concerts, weddings, movie shows, festivals, public gatherings and every BAM security assignment.</p></div>
<?php if($msg):?><div class="alert alert-ok"><?=e($msg)?></div><?php endif;?><?php if($error):?><div class="alert alert-error"><?=e($error)?></div><?php endif;?>
<section class="card">
<h2><?=$editing?'Edit Event':'Add Event'?></h2>
<form method="post" class="form-grid"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="id" value="<?=e($editing['id']??0)?>">
<div class="field"><label>Event Name</label><input name="event_name" required value="<?=e($editing['event_name']??'')?>"></div>
<div class="field"><label>Event Type</label><input name="event_type" placeholder="Concert / Wedding / Festival / Public Event" value="<?=e($editing['event_type']??'')?>"></div>
<div class="field"><label>Organizer / Client</label><input name="client_name" value="<?=e($editing['client_name']??'')?>"></div>
<div class="field"><label>Venue / Location</label><input name="location" value="<?=e($editing['location']??'')?>"></div>
<div class="field"><label>Event Date</label><input type="date" name="event_date" value="<?=e($editing['event_date']??'')?>"></div>
<div class="field"><label>Status</label><select name="status"><?php foreach(['planned','confirmed','ongoing','completed','cancelled'] as $x):?><option value="<?=$x?>" <?=$x===($editing['status']??'planned')?'selected':''?>><?=strtoupper($x)?></option><?php endforeach;?></select></div>
<div class="field"><label>Start Time</label><input type="time" name="start_time" value="<?=e($editing['start_time']??'')?>"></div>
<div class="field"><label>End Time</label><input type="time" name="end_time" value="<?=e($editing['end_time']??'')?>"></div>
<div class="field"><label>Personnel Required</label><input type="number" min="0" name="personnel_required" value="<?=e($editing['personnel_required']??0)?>"></div>
<div class="field"><label>Personnel Deployed</label><input type="number" min="0" name="personnel_deployed" value="<?=e($editing['personnel_deployed']??0)?>"></div>
<div class="field full"><label>Operational Notes</label><textarea name="notes"><?=e($editing['notes']??'')?></textarea></div>
<div class="full admin-actions"><button class="btn btn-red">Save Event</button><?php if($editing):?><a class="btn btn-light" href="events.php">New Event</a><?php endif;?></div></form>
</section>
<section class="card"><div style="display:flex;justify-content:space-between;gap:10px;align-items:center;flex-wrap:wrap"><h2 style="margin:0">Event History</h2><form style="display:flex;gap:8px;flex-wrap:wrap" method="get"><input name="q" value="<?=e($q)?>" placeholder="Search event / organizer / venue" style="min-width:220px"><select name="status"><option value="">All statuses</option><?php foreach(['planned','confirmed','ongoing','completed','cancelled'] as $x):?><option <?=$x===$status?'selected':''?>><?=$x?></option><?php endforeach;?></select><button class="btn btn-dark">Filter</button></form></div>
<div class="table-wrap" style="margin-top:15px"><table class="table"><tr><th>Date</th><th>Event</th><th>Venue</th><th>Personnel</th><th>Status</th><th>Actions</th></tr><?php foreach($rows as $r):?><tr><td><?=e($r['event_date']?:'TBD')?></td><td><b><?=e($r['event_name'])?></b><br><span class="muted"><?=e($r['event_type']?:'Security assignment')?></span></td><td><?=e($r['location']?:'—')?><br><span class="muted"><?=e($r['client_name']?:'')?></span></td><td><?=e($r['personnel_deployed'])?> / <?=e($r['personnel_required'])?></td><td><span class="status <?=$r['status']==='completed'?'status-active':($r['status']==='cancelled'?'status-expired':'status-inactive')?>"><?=e($r['status'])?></span></td><td><a class="btn btn-light" href="events.php?edit=<?=$r['id']?>">Edit</a> <form method="post" style="display:inline" onsubmit="return confirm('Remove this event?')"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?=$r['id']?>"><button class="btn btn-dark" type="submit">Remove</button></form></td></tr><?php endforeach;?></table></div>
<?php if(!$rows):?><div class="notice" style="margin-top:15px">No events found.</div><?php endif;?></section>
</main><footer class="footer"><div class="container" style="padding-bottom:25px">Bouncer Association of Meghalaya • Secure Administration</div></footer>
</body></html>