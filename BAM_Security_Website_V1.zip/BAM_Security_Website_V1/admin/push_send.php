<?php
require_once __DIR__.'/../config/config.php';
admin_required();
$wantsJson = (stripos((string)($_SERVER['HTTP_ACCEPT']??''),'application/json')!==false) || !empty($_SERVER['HTTP_X_REQUESTED_WITH']);
if($_SERVER['REQUEST_METHOD']!=='POST'){
    http_response_code(405);
    if($wantsJson){header('Content-Type: application/json; charset=utf-8');echo json_encode(['ok'=>false,'error'=>'POST required.']);exit;}
    redirect('settings.php#pwa');
}
verify_csrf();
$title=trim((string)($_POST['title']??'BAM Admin'));$body=trim((string)($_POST['body']??''));$url=trim((string)($_POST['url']??'/admin/'));
if($body===''){http_response_code(422);exit('Notification message is required.');}
$ok=0;$subs=pwa_get_subscriptions();$keep=[];$errors=[];foreach($subs as $sub){try{if(pwa_send_web_push($sub,$title,$body,$url)){$ok++;$keep[]=$sub;}else{$keep[]=$sub;}}catch(Throwable $e){$errors[]=$e->getMessage();error_log('BAM push: '.$e->getMessage());$keep[]=$sub;}}pwa_save_subscriptions($keep);audit('PWA_PUSH_SENT');if(stripos((string)($_SERVER['HTTP_ACCEPT']??''),'application/json')!==false){header('Content-Type: application/json; charset=utf-8');echo json_encode(['ok'=>$ok>0,'sent'=>$ok,'subscriptions'=>count($subs),'error'=>$ok===0?(count($subs)?'The notification could not be delivered. Check that this device is subscribed and push service is available.':'No admin device is subscribed to push notifications yet. Press Enable Admin Notifications on this device first.'):null]);exit;}redirect('settings.php#pwa');
