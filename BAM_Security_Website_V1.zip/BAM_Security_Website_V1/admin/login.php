<?php
require_once __DIR__.'/../config/config.php';
if(!empty($_SESSION['admin_id'])) redirect('index.php');
$error='';
if(isset($_GET['timeout'])) $error='Your BAM admin session expired after 60 minutes of inactivity. Please sign in again.';
if($_SERVER['REQUEST_METHOD']==='POST'){
    verify_csrf();
    try{
        $stmt=db()->prepare('SELECT * FROM admins WHERE email=? LIMIT 1');
        $stmt->execute([trim($_POST['email']??'')]);
        $a=$stmt->fetch();
        if($a && password_verify($_POST['password']??'',$a['password_hash'])){
            session_regenerate_id(true);$_SESSION['admin_id']=$a['id'];$_SESSION['admin_name']=$a['username'] ?? $a['email'];$_SESSION['admin_last_activity']=time();setcookie('bam_admin_session','1',['expires'=>time()+ADMIN_IDLE_TIMEOUT,'path'=>'/','secure'=>(!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off'),'httponly'=>true,'samesite'=>'Lax']);audit('ADMIN_LOGIN');redirect('index.php');
        }
        $error='Invalid email or password.';
    }catch(Throwable $e){error_log('Admin login: '.$e->getMessage());$error='Unable to connect to the database. Please check the installation and database configuration.';}
}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>BAM Admin Login</title><link rel="stylesheet" href="../assets/admin.css?v=64"><link rel="manifest" href="/admin/manifest.json"><link rel="apple-touch-icon" href="/admin/apple-touch-icon.png"><script src="pwa.js?v=64" defer></script></head><body class="admin-page"><script>document.documentElement.dataset.adminTheme=<?=json_encode(get_setting('site_theme','night'))?>;</script>
<div class="container"><div class="card login-box"><img src="../assets/bam-logo.png" style="width:100%;max-height:120px;object-fit:contain;background:#000;border-radius:8px"><h1>Admin Login</h1>
<?php if($error):?><div class="alert alert-error"><?=e($error)?></div><?php endif;?>
<form method="post"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><div class="field"><label>Email</label><input type="email" name="email" required></div><br><div class="field"><label>Password</label><div class="password-wrap"><input type="password" name="password" autocomplete="current-password" required><button type="button" class="password-toggle" aria-label="Show password" title="Show password">Show</button></div></div><br><button class="btn btn-red">Sign In</button></form>
<br><a href="../">Back to website</a></div></div></body></html>