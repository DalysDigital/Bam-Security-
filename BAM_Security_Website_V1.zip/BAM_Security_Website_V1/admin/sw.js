const CACHE_VERSION='bam-admin-v64';
const STATIC_CACHE=`${CACHE_VERSION}-static`;
const OFFLINE_URL='/admin/offline.html';
const STATIC_ASSETS=[
  '/admin/offline.html',
  '/assets/admin.css?v=64',
  '/assets/icon-192.png',
  '/assets/icon-512.png',
  '/assets/bam-logo.png',
  '/assets/bam-logo-day.png',
  '/admin/pwa.js?v=64'
];
self.addEventListener('install',event=>{event.waitUntil(caches.open(STATIC_CACHE).then(cache=>cache.addAll(STATIC_ASSETS)).then(()=>self.skipWaiting()));});
self.addEventListener('activate',event=>{event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('bam-admin-')&&k!==STATIC_CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));});
self.addEventListener('message',event=>{if(event.data?.type==='SKIP_WAITING') self.skipWaiting();});
self.addEventListener('fetch',event=>{
  const req=event.request; if(req.method!=='GET') return;
  const url=new URL(req.url); if(url.origin!==self.location.origin || !url.pathname.startsWith('/admin/')) return;
  // Never cache private/admin HTML, PHP, JSON or API responses. Network failure gets a generic offline shell.
  if(req.mode==='navigate' || url.pathname.endsWith('.php') || url.pathname.startsWith('/admin/push')){
    event.respondWith(fetch(req,{cache:'no-store'}).catch(()=>caches.match(OFFLINE_URL)));
    return;
  }
  // Static assets are cache-first, then refreshed when available.
  event.respondWith(caches.match(req).then(cached=>cached||fetch(req).then(res=>{if(res.ok && (url.pathname.startsWith('/assets/')||url.pathname.startsWith('/admin/'))){const copy=res.clone();caches.open(STATIC_CACHE).then(c=>c.put(req,copy));}return res;}).catch(()=>cached||caches.match(OFFLINE_URL))));
});

self.addEventListener('push',event=>{
  let data={title:'BAM Admin',body:'New administration notification.',url:'/admin/'};
  try{if(event.data){const x=event.data.json();data=Object.assign(data,x);}}catch(e){}
  event.waitUntil(self.registration.showNotification(data.title,{body:data.body,icon:'/assets/icon-192.png',badge:'/assets/icon-192.png',tag:'bam-admin',data:{url:data.url||'/admin/'},renotify:true}));
});
self.addEventListener('notificationclick',event=>{event.notification.close();const target=new URL(event.notification.data?.url||'/admin/',self.location.origin).href;event.waitUntil(clients.matchAll({type:'window',includeUncontrolled:true}).then(list=>{for(const c of list){if(c.url.startsWith(self.location.origin+'/admin/')&&'focus' in c)return c.navigate(target).then(()=>c.focus());}return clients.openWindow(target);}));});
