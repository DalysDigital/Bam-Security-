<?php
require_once __DIR__.'/../config/config.php';
admin_required();
ensure_settings_table();
ensure_id_fields_table();
$error=''; $ok='';
if($_SERVER['REQUEST_METHOD']==='POST'){
  verify_csrf();
  try{
    $section=$_POST['section']??'invoice';
    $invoiceKeys=['invoice_title','invoice_address','invoice_phone','invoice_email','invoice_instagram','invoice_thank_you','invoice_footer','invoice_signature_caption','invoice_currency','invoice_words_label','president_name','president_title'];
    $idKeys=['id_size','id_front_footer','id_back_title','id_back_note','id_back_footer','id_front_bg','id_back_bg','id_accent','id_logo'];
    $verifyKeys=['verify_title','verify_subtitle','verify_prompt','verify_invalid','verify_footer','verify_badge_style'];
    $letterKeys=['letter_default_no','letter_default_closing','letter_default_signature_caption','letter_default_signatory_name','letter_default_signatory_title','letter_footer_address','letter_footer_phone','letter_footer_email','letter_footer_instagram'];
    if($section==='appearance'){ set_setting('site_theme',($_POST['site_theme']??'night')==='day'?'day':'night'); audit('APPEARANCE_SETTINGS_UPDATED'); $ok='Appearance settings saved.'; } elseif($section==='invoice'){
      foreach($invoiceKeys as $k) set_setting($k,trim((string)($_POST[$k]??'')));
      if(!empty($_FILES['invoice_logo']['name'])){
        if($_FILES['invoice_logo']['size']>MAX_UPLOAD_BYTES) throw new RuntimeException('Invoice logo is too large.');
        $mime=(new finfo(FILEINFO_MIME_TYPE))->file($_FILES['invoice_logo']['tmp_name']);
        $allowed=['image/png'=>'png','image/jpeg'=>'jpg','image/webp'=>'webp'];
        if(!isset($allowed[$mime])) throw new RuntimeException('Invoice logo must be PNG, JPG or WebP.');
        $name='bam-invoice-logo-'.bin2hex(random_bytes(5)).'.'.$allowed[$mime];
        if(!move_uploaded_file($_FILES['invoice_logo']['tmp_name'],UPLOAD_DIR.$name)) throw new RuntimeException('Could not save invoice logo.');
        set_setting('invoice_logo','uploads/'.$name);
      }
      if(!empty($_FILES['president_signature']['name'])){
        if($_FILES['president_signature']['size']>MAX_UPLOAD_BYTES) throw new RuntimeException('Signature image is too large.');
        $mime=(new finfo(FILEINFO_MIME_TYPE))->file($_FILES['president_signature']['tmp_name']);
        $allowed=['image/png'=>'png','image/jpeg'=>'jpg','image/webp'=>'webp'];
        if(!isset($allowed[$mime])) throw new RuntimeException('Signature must be PNG, JPG or WebP.');
        $name='bam-signature-'.bin2hex(random_bytes(6)).'.'.$allowed[$mime];
        if(!move_uploaded_file($_FILES['president_signature']['tmp_name'],UPLOAD_DIR.$name)) throw new RuntimeException('Could not save signature.');
        set_setting('president_signature',$name);
      }
      audit('INVOICE_SETTINGS_UPDATED'); $ok='Invoice settings saved.';
    } elseif($section==='id'){
      foreach($idKeys as $k) set_setting($k,trim((string)($_POST[$k]??'')));
      if(!empty($_FILES['id_logo_upload']['name'])){
        if($_FILES['id_logo_upload']['size']>MAX_UPLOAD_BYTES) throw new RuntimeException('ID logo is too large.');
        $mime=(new finfo(FILEINFO_MIME_TYPE))->file($_FILES['id_logo_upload']['tmp_name']);
        $allowed=['image/png'=>'png','image/jpeg'=>'jpg','image/webp'=>'webp'];
        if(!isset($allowed[$mime])) throw new RuntimeException('ID logo must be PNG, JPG or WebP.');
        $name='bam-id-logo-'.bin2hex(random_bytes(5)).'.'.$allowed[$mime];
        if(!move_uploaded_file($_FILES['id_logo_upload']['tmp_name'],UPLOAD_DIR.$name)) throw new RuntimeException('Could not save ID logo.');
        set_setting('id_logo','uploads/'.$name);
      }
      audit('ID_SETTINGS_UPDATED'); $ok='ID settings saved.';
    } elseif($section==='letter'){
      foreach($letterKeys as $k) set_setting($k,trim((string)($_POST[$k]??'')));
      set_setting('letter_show_no',isset($_POST['letter_show_no'])?'1':'0');
      set_setting('letter_show_date',isset($_POST['letter_show_date'])?'1':'0');
      if(!empty($_FILES['letterhead_image']['name'])){
        if($_FILES['letterhead_image']['size']>MAX_UPLOAD_BYTES) throw new RuntimeException('Letterhead image is too large.');
        $mime=(new finfo(FILEINFO_MIME_TYPE))->file($_FILES['letterhead_image']['tmp_name']);
        $allowed=['image/png'=>'png','image/jpeg'=>'jpg','image/webp'=>'webp'];
        if(!isset($allowed[$mime])) throw new RuntimeException('Letterhead must be PNG, JPG or WebP.');
        $name='bam-letterhead-'.bin2hex(random_bytes(5)).'.'.$allowed[$mime];
        if(!move_uploaded_file($_FILES['letterhead_image']['tmp_name'],UPLOAD_DIR.$name)) throw new RuntimeException('Could not save letterhead.');
        set_setting('letterhead_image','uploads/'.$name);
      }
      audit('LETTER_SETTINGS_UPDATED'); $ok='Letter settings saved.';
    } elseif($section==='verification'){
      foreach($verifyKeys as $k) set_setting($k,trim((string)($_POST[$k]??'')));
      $toggles=['verify_public_search','verify_show_member_id','verify_show_designation','verify_show_phone','verify_show_email','verify_show_address','verify_show_events','verify_show_joined_date','verify_show_valid_until','verify_show_status'];
      foreach($toggles as $k) set_setting($k,isset($_POST[$k])?'1':'0');
      audit('VERIFICATION_SETTINGS_UPDATED'); $ok='Verification settings saved.';
    }
  }catch(Throwable $e){$error=$e->getMessage();}
}
function checked_setting(string $k): string { return get_setting($k,'0')==='1'?'checked':''; }
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#e30613"><title>BAM Settings</title><link rel="stylesheet" href="../assets/admin.css?v=64"><link rel="manifest" href="/admin/manifest.json"><link rel="apple-touch-icon" href="/admin/apple-touch-icon.png"><script src="pwa.js?v=64" defer></script></head><body class="admin-page"><script>document.documentElement.dataset.adminTheme=<?=json_encode(get_setting('site_theme','night'))?>;</script>
<header class="topbar"><div class="container nav"><a class="brand" href="index.php"><img src="<?=get_setting('site_theme','night')==='day'?'../assets/bam-logo-day.png':'../assets/bam-logo.png'?>" alt="BAM"><strong>BAM ADMIN</strong></a><?php $base='';include __DIR__.'/_nav.php';?></div></header>
<main class="container"><div class="eyebrow">BAM // CONFIGURATION</div><h1>System Settings</h1><p class="muted">Manage Invoice, Membership ID and Public Verification separately.</p>
<?php if($error):?><div class="alert alert-error"><?=e($error)?></div><?php endif;?><?php if($ok):?><div class="alert alert-ok"><?=e($ok)?></div><?php endif;?>
<section class="card"><div class="eyebrow">APPEARANCE SETTINGS</div><h2>Day / Night Theme</h2><form method="post"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="section" value="appearance"><div class="form-grid"><div class="field"><label>Admin / Verification Theme</label><select name="site_theme"><option value="night" <?=get_setting('site_theme','night')==='night'?'selected':''?>>Night — Black Security Theme</option><option value="day" <?=get_setting('site_theme','night')==='day'?'selected':''?>>Day — Light Theme</option></select><div class="small muted">Day mode uses the light BAM logo; Night mode uses the transparent BAM logo.</div></div></div><br><button class="btn btn-red">Save Appearance</button></form></section>

<section class="card"><div class="eyebrow">INVOICE SETTINGS</div><h2>Official Bill / Invoice</h2><form method="post" enctype="multipart/form-data"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="section" value="invoice"><div class="form-grid">
<div class="field"><label>Bill Title</label><input name="invoice_title" value="<?=e(get_setting('invoice_title','BILL'))?>"></div>
<div class="field"><label>Invoice Logo (transparent PNG recommended)</label><input type="file" name="invoice_logo" accept="image/png,image/jpeg,image/webp"><div class="small muted">Used as the top-right logo and logo-only watermark.</div></div>
<div class="field"><label>Currency Symbol</label><input name="invoice_currency" value="<?=e(get_setting('invoice_currency','₹'))?>"></div>
<div class="field"><label>President / Signatory Name</label><input name="president_name" value="<?=e(get_setting('president_name','Junestar Kharbuli'))?>"></div>
<div class="field"><label>President / Signatory Title</label><input name="president_title" value="<?=e(get_setting('president_title','PRESIDENT'))?>"><div class="small muted">This is the title printed below the signature/name on the invoice.</div></div>
<div class="field"><label>Digital Signature</label><input type="file" name="president_signature" accept="image/png,image/jpeg,image/webp"><?php if(get_setting('president_signature')):?><img src="<?=e(APP_URL.'/uploads/'.rawurlencode(get_setting('president_signature')))?>" style="max-width:180px;max-height:70px;background:#fff;padding:4px;margin-top:8px;border-radius:6px"><?php endif;?></div>
<div class="field"><label>Address</label><input name="invoice_address" value="<?=e(get_setting('invoice_address'))?>"></div><div class="field"><label>Phone</label><input name="invoice_phone" value="<?=e(get_setting('invoice_phone'))?>"></div><div class="field"><label>Email</label><input name="invoice_email" value="<?=e(get_setting('invoice_email'))?>"></div><div class="field"><label>Instagram</label><input name="invoice_instagram" value="<?=e(get_setting('invoice_instagram'))?>"></div><div class="field"><label>Thank You Text</label><input name="invoice_thank_you" value="<?=e(get_setting('invoice_thank_you','THANK YOU!'))?>"></div><div class="field"><label>Signature Caption</label><input name="invoice_signature_caption" value="<?=e(get_setting('invoice_signature_caption','Yours faithfully'))?>"></div><div class="field"><label>Amount in Words Label</label><input name="invoice_words_label" value="<?=e(get_setting('invoice_words_label','Amount in Words:'))?>"></div><div class="field full"><label>Invoice Footer</label><input name="invoice_footer" value="<?=e(get_setting('invoice_footer'))?>"></div></div><br><button class="btn btn-red">Save Invoice Settings</button></form></section>

<section class="card"><div class="eyebrow">LETTER SETTINGS</div><h2>BAM Official Letterhead</h2><p class="muted">The letter editor uses the BAM letterhead as the A4 background. You can replace it with your own PNG/JPG/WebP at any time.</p><form method="post" enctype="multipart/form-data"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="section" value="letter"><div class="form-grid">
<div class="field full"><label>Letterhead Image</label><input type="file" name="letterhead_image" accept="image/png,image/jpeg,image/webp"><?php $lh=get_setting('letterhead_image','assets/bam-letterhead.png'); ?><div class="small muted">Recommended: A4 portrait artwork. Current: <?=e($lh)?></div></div>
<div class="field"><label>Default Red Letter No.</label><input name="letter_default_no" value="<?=e(get_setting('letter_default_no','BAM/LET/'.date('Y').'/0001'))?>"></div>
<div class="field"><label>Default Signatory Name</label><input name="letter_default_signatory_name" value="<?=e(get_setting('letter_default_signatory_name',get_setting('president_name','Junestar Kharbuli')))?>"></div>
<div class="field"><label>Default Signatory Title</label><input name="letter_default_signatory_title" value="<?=e(get_setting('letter_default_signatory_title',get_setting('president_title','PRESIDENT')))?>"></div>
<div class="field"><label>Signature Caption</label><input name="letter_default_signature_caption" value="<?=e(get_setting('letter_default_signature_caption','Yours faithfully'))?>"></div>
<div class="field"><label>Closing Text</label><input name="letter_default_closing" value="<?=e(get_setting('letter_default_closing','Thank you'))?>"></div>
<div class="field"><label>Footer Address</label><input name="letter_footer_address" value="<?=e(get_setting('letter_footer_address',get_setting('invoice_address','Malki Point - 793001')))?>"></div>
<div class="field"><label>Footer Phone</label><input name="letter_footer_phone" value="<?=e(get_setting('letter_footer_phone',get_setting('invoice_phone','+91 70056 68453 / +91 70058 61828')))?>"></div>
<div class="field"><label>Footer Email</label><input name="letter_footer_email" value="<?=e(get_setting('letter_footer_email',get_setting('invoice_email','e2kharkongor@gmail.com')))?>"></div>
<div class="field"><label>Footer Instagram</label><input name="letter_footer_instagram" value="<?=e(get_setting('letter_footer_instagram',get_setting('invoice_instagram','@meghalaya_bouncer')))?>"></div>
<div class="field full" style="display:flex;gap:20px;flex-wrap:wrap"><label><input type="checkbox" name="letter_show_no" <?=checked_setting('letter_show_no')?>> Show letter no.</label><label><input type="checkbox" name="letter_show_date" <?=checked_setting('letter_show_date')?>> Show date</label></div>
</div><br><button class="btn btn-red">Save Letter Settings</button></form></section>

<section class="card" id="pwa"><div class="eyebrow">ADMIN APP / PWA</div><h2>Secure Admin App</h2><p class="muted">The public BAM website remains a normal website. Only <b>/admin/</b> is installable as the secure administration app. Static assets can work from cache when offline; private dashboard/database responses are never stored in Cache Storage.</p><div class="admin-actions" style="margin-top:14px"><button type="button" class="btn btn-red" id="enablePushBtn">Enable Admin Notifications</button><a class="btn btn-light" href="/admin/manifest.json" target="_blank" rel="noopener">View App Manifest</a></div><div id="pushStatus" class="small muted" style="margin-top:10px">Notifications are opt-in and will only be requested after you press the button.</div><form method="post" action="push_send.php" id="pushTestForm" style="margin-top:18px;max-width:760px"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><div class="form-grid"><div class="field"><label>Notification Title</label><input name="title" value="BAM Admin Alert"></div><div class="field"><label>Deep Link</label><input name="url" value="/admin/"></div><div class="field full"><label>Test Notification Message</label><input name="body" placeholder="Test notification from BAM Admin" required></div></div><button class="btn btn-light" style="margin-top:12px" type="submit">Send Test Notification</button><div id="pushTestStatus" class="small muted" style="margin-top:10px" aria-live="polite"></div></form></section>

<section class="card"><div class="eyebrow">ID SETTINGS</div><h2>Digital Membership ID</h2><p class="muted">Front remains Name + Designation. Back/QR side is configurable here.</p><form method="post" enctype="multipart/form-data"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="section" value="id"><div class="form-grid">
<div class="field full"><label>Membership ID Size</label><select name="id_size"><option value="55x85" <?=get_setting('id_size','80x100')==='55x85'?'selected':''?>>Option 1 — ATM / Standard: 5.5 × 8.5 cm</option><option value="85x55" <?=get_setting('id_size','80x100')==='85x55'?'selected':''?>>Option 2 — Landscape: 8.5 × 5.5 cm</option><option value="80x100" <?=get_setting('id_size','80x100')==='80x100'?'selected':''?>>Option 3 — Large: 8 × 10 cm</option></select></div>
<div class="field"><label>ID Logo (transparent PNG recommended)</label><input type="file" name="id_logo_upload" accept="image/png,image/jpeg,image/webp"><input type="text" name="id_logo" value="<?=e(get_setting('id_logo','assets/bam-logo.png'))?>"></div><div class="field"><label>Front Background</label><input type="color" name="id_front_bg" value="<?=e(get_setting('id_front_bg','#090909'))?>"></div><div class="field"><label>Back Background</label><input type="color" name="id_back_bg" value="<?=e(get_setting('id_back_bg','#090909'))?>"></div><div class="field"><label>Accent</label><input type="color" name="id_accent" value="<?=e(get_setting('id_accent','#e30613'))?>"></div><div class="field"><label>Front Footer</label><input name="id_front_footer" value="<?=e(get_setting('id_front_footer'))?>"></div><div class="field"><label>Back Title</label><input name="id_back_title" value="<?=e(get_setting('id_back_title'))?>"></div><div class="field full"><label>Back Verification Note</label><textarea name="id_back_note"><?=e(get_setting('id_back_note'))?></textarea></div><div class="field full"><label>Back Footer</label><input name="id_back_footer" value="<?=e(get_setting('id_back_footer'))?>"></div></div><br><button class="btn btn-red">Save ID Settings</button></form><div class="admin-actions" style="margin-top:15px"><a class="btn btn-light" href="id_fields.php">Manage Custom Member Fields</a></div></section>

<section class="card"><div class="eyebrow">PUBLIC VERIFICATION SETTINGS</div><h2>Verification Confirmed Page</h2><p class="muted">The member photo and member name are always shown. Everything else below can be turned on or off. Custom fields marked Public QR in ID Fields are also shown.</p><form method="post"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="section" value="verification"><div class="form-grid">
<div class="field"><label>Confirmed Page Title</label><input name="verify_title" value="<?=e(get_setting('verify_title','Verification Confirmed.'))?>"></div><div class="field"><label>Member Label</label><input name="verify_subtitle" value="<?=e(get_setting('verify_subtitle','Verified BAM Member'))?>"></div>
<div class="field full"><label>QR Verification Intro</label><textarea name="verify_prompt"><?=e(get_setting('verify_prompt'))?></textarea></div><div class="field full"><label>Invalid Verification Message</label><textarea name="verify_invalid"><?=e(get_setting('verify_invalid'))?></textarea></div>
<div class="field full" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px"><label><input type="checkbox" name="verify_show_member_id" <?=checked_setting('verify_show_member_id')?>> Member ID</label><label><input type="checkbox" name="verify_show_designation" <?=checked_setting('verify_show_designation')?>> Designation</label><label><input type="checkbox" name="verify_show_phone" <?=checked_setting('verify_show_phone')?>> Phone</label><label><input type="checkbox" name="verify_show_email" <?=checked_setting('verify_show_email')?>> Email</label><label><input type="checkbox" name="verify_show_address" <?=checked_setting('verify_show_address')?>> Address</label><label><input type="checkbox" name="verify_show_events" <?=checked_setting('verify_show_events')?>> Events / Assignment</label><label><input type="checkbox" name="verify_show_joined_date" <?=checked_setting('verify_show_joined_date')?>> Joined Date</label><label><input type="checkbox" name="verify_show_valid_until" <?=checked_setting('verify_show_valid_until')?>> Valid Until</label><label><input type="checkbox" name="verify_show_status" <?=checked_setting('verify_show_status')?>> Status</label></div>
<div class="field full"><label><input type="checkbox" name="verify_public_search" <?=checked_setting('verify_public_search')?>> Allow public Member ID search</label><div class="small muted">When enabled, visitors can enter a Member ID on the public verification page. QR verification remains available.</div></div><div class="field"><label>Verified Badge</label><select name="verify_badge_style"><option value="green" <?=get_setting('verify_badge_style','green')==='green'?'selected':''?>>Green verification tick</option><option value="blue" <?=get_setting('verify_badge_style','green')==='blue'?'selected':''?>>Blue verification V</option></select></div><div class="field full"><label>Verification Footer</label><input name="verify_footer" value="<?=e(get_setting('verify_footer'))?>"></div></div><br><button class="btn btn-red">Save Verification Settings</button></form><div class="admin-actions" style="margin-top:15px"><a class="btn btn-light" href="id_fields.php">Configure Custom QR Fields</a><a class="btn btn-light" href="../verify.php" target="_blank">Preview Verification</a></div></section>
</main><script>
(function(){const b=document.getElementById('enablePushBtn'),s=document.getElementById('pushStatus');if(b)b.addEventListener('click',async()=>{b.disabled=true;s.textContent='Requesting notification permission…';try{await window.bamAdminEnablePush();s.textContent='Push notifications are enabled for this administrator on this device.';}catch(e){s.textContent=e.message||'Notifications could not be enabled.';}finally{b.disabled=false;}});const f=document.getElementById('pushTestForm'),st=document.getElementById('pushTestStatus');if(f)f.addEventListener('submit',async e=>{e.preventDefault();const btn=f.querySelector('button[type=submit]');btn.disabled=true;st.textContent='Sending test notification…';try{const res=await fetch(f.action,{method:'POST',credentials:'same-origin',headers:{'Accept':'application/json'},body:new FormData(f)});const data=await res.json().catch(()=>({ok:false,error:'The server returned an invalid response.'}));if(!res.ok||!data.ok)throw new Error(data.error||'Test notification could not be sent.');st.textContent='Test notification sent successfully.';}catch(err){st.textContent=err.message||'Test notification could not be sent.';}finally{btn.disabled=false;}});})();
</script></body></html>
