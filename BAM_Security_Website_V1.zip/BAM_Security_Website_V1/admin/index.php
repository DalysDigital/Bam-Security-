<?php
require_once __DIR__.'/../config/config.php';
admin_required();
ensure_events_table(); ensure_invoice_table(); ensure_letters_table();
$total=(int)db()->query('SELECT COUNT(*) FROM members')->fetchColumn();
$active=(int)db()->query("SELECT COUNT(*) FROM members WHERE status='active'")->fetchColumn();
$inactive=(int)db()->query("SELECT COUNT(*) FROM members WHERE status<>'active'")->fetchColumn();
$events=(int)db()->query('SELECT COUNT(*) FROM events')->fetchColumn();
$invoices=(int)db()->query('SELECT COUNT(*) FROM invoices')->fetchColumn();
$letters=(int)db()->query('SELECT COUNT(*) FROM letters')->fetchColumn();
$upcoming=(int)db()->query("SELECT COUNT(*) FROM events WHERE event_date>=CURDATE() AND status IN ('planned','confirmed','ongoing')")->fetchColumn();
$recent=db()->query("SELECT * FROM events ORDER BY event_date DESC, id DESC LIMIT 8")->fetchAll();
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#060606"><title>BAM Control Centre</title><link rel="stylesheet" href="../assets/admin.css?v=64"><link rel="manifest" href="/admin/manifest.json"><link rel="apple-touch-icon" href="/admin/apple-touch-icon.png"><script src="pwa.js?v=64" defer></script></head><body class="admin-page"><script>document.documentElement.dataset.adminTheme=<?=json_encode(get_setting('site_theme','night'))?>;</script>
<header class="topbar"><div class="container nav"><a class="brand" href="index.php"><img src="<?=get_setting('site_theme','night')==='day'?'../assets/bam-logo-day.png':'../assets/bam-logo.png'?>" alt="BAM"><strong style="letter-spacing:.14em;font-size:11px">BAM ADMIN</strong></a><?php $base=""; include __DIR__.'/_nav.php'; ?></div></header>
<main class="container">
<div style="margin-bottom:24px"><div style="font-size:9px;letter-spacing:.22em;color:#777;font-weight:900">BAM // SECURE CONTROL CENTRE</div><h1>Professional Security.<br><span style="color:#e30613">Controlled Operations.</span></h1><p class="muted" style="max-width:720px">Manage BAM members, digital IDs, verification and the complete history of security events from one responsive control centre.</p></div>
<div class="stats">
<div class="stat">Total Members<strong><?=$total?></strong><span><?=$active?> active IDs</span></div>
<div class="stat">Events Managed<strong><?=$events?></strong><span><?=$upcoming?> upcoming</span></div>
<div class="stat">Inactive / Expired<strong><?=$inactive?></strong><span>Membership records</span></div>
<div class="stat">Invoices<strong><?=$invoices?></strong><span>Saved billing records</span></div>
<div class="stat">Letters<strong><?=$letters?></strong><span>Saved correspondence</span></div>
</div>
<div class="admin-actions" style="margin:18px 0 22px">
<a class="btn btn-red" href="member_form.php">+ Add New Member</a>
<a class="btn btn-dark" href="events.php">◆ Manage Events</a>
<a class="btn btn-light" href="../verify.php" target="_blank">Verify ID</a>
<a class="btn btn-light" href="invoices.php">Invoices</a>
<a class="btn btn-light" href="letters.php">Letters</a>
<a class="btn btn-light" href="frontend.php">Website Editor</a>
</div>
<section class="card">
<div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap">
<div><div style="font-size:9px;letter-spacing:.2em;color:#777;font-weight:900">FIELD OPERATIONS</div><h2 style="margin:5px 0 0">Events Managed</h2></div>
<a class="btn btn-red" href="events.php?action=new">+ Add Event</a></div>
<?php if($recent): ?>
<div class="table-wrap" style="margin-top:15px"><table class="table"><tr><th>Date</th><th>Event</th><th>Venue / Client</th><th>Personnel</th><th>Status</th><th></th></tr>
<?php foreach($recent as $r):?><tr>
<td><?=e($r['event_date']?:'TBD')?></td>
<td><b><?=e($r['event_name'])?></b><br><span class="muted"><?=e($r['event_type']?:'Security assignment')?></span></td>
<td><?=e($r['location']?:'Venue not set')?><br><span class="muted"><?=e($r['client_name']?:'')?></span></td>
<td><?=e($r['personnel_deployed'])?> / <?=e($r['personnel_required'])?></td>
<td><span class="status <?=in_array($r['status'],['COMPLETED'],true)?'status-active':($r['status']==='cancelled'?'status-expired':'status-inactive')?>"><?=e($r['status'])?></span></td>
<td><a class="btn btn-light" href="events.php?edit=<?=$r['id']?>">Edit</a></td>
</tr><?php endforeach;?></table></div>
<?php else: ?><div class="notice" style="margin-top:15px">No events have been recorded yet. Add the first BAM security assignment to build your operations history.</div><?php endif;?>
</section>
<section class="grid" style="margin-top:16px">
<div class="card"><div style="font-size:9px;letter-spacing:.18em;color:#777;font-weight:900">MEMBERSHIP</div><h2>Latest Member Records</h2><p class="muted">Create, update and print digital BAM IDs.</p><a class="btn btn-dark" href="members.php">Manage Members</a></div>
<div class="card"><div style="font-size:9px;letter-spacing:.18em;color:#777;font-weight:900">VERIFICATION</div><h2>QR-only Public Verification</h2><p class="muted">The public verification page can be opened from a BAM QR code or verification link.</p><a class="btn btn-light" href="../verify.php" target="_blank">Open Verification</a></div>
<div class="card"><div style="font-size:9px;letter-spacing:.18em;color:#777;font-weight:900">BILLING</div><h2>Invoices & Bills</h2><p class="muted">Create, save, edit and print BAM bills using the official invoice layout.</p><a class="btn btn-red" href="invoices.php">Open Invoices</a></div>
<div class="card"><div style="font-size:9px;letter-spacing:.18em;color:#777;font-weight:900">CORRESPONDENCE</div><h2>Letters & Letterhead</h2><p class="muted">Create official BAM letters with rich text, tables and the BAM letterhead.</p><a class="btn btn-red" href="letters.php">Open Letters</a></div>
<div class="card"><div style="font-size:9px;letter-spacing:.18em;color:#777;font-weight:900">SECURITY</div><h2>Activity Audit</h2><p class="muted">Review administrator actions and membership changes.</p><a class="btn btn-light" href="audit.php">View Activity</a></div>
</section>
</main>
<footer class="footer"><div class="container" style="padding-bottom:25px">Bouncer Association of Meghalaya • Secure Administration</div></footer>
</body></html>