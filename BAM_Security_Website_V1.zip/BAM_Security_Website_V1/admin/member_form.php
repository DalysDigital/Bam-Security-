<?php
require_once __DIR__.'/../config/config.php';
admin_required(); ensure_member_schema(); ensure_member_password_column(); ensure_id_fields_table();
$error='';$ok='';$id=(int)($_GET['id']??0);$member=$id?db()->query('SELECT * FROM members WHERE id='.(int)$id)->fetch():null;
if(!$member && isset($_GET['member'])) $member=member_by_id(trim($_GET['member']));
$id=(int)($member['id']??0);
$fields=db()->query("SELECT * FROM id_fields WHERE active=1 ORDER BY sort_order,id")->fetchAll();
$custom=[]; if($member && !empty($member['custom_data'])){ $x=json_decode((string)$member['custom_data'],true); if(is_array($x))$custom=$x; }
if($_SERVER['REQUEST_METHOD']==='POST'){
  verify_csrf();
  try{
    $id=(int)($_POST['id']??0); $member=$id?db()->query('SELECT * FROM members WHERE id='.(int)$id)->fetch():null;
    $memberNo=trim($_POST['member_no']??'');$name=trim($_POST['name']??'');$designation=trim($_POST['designation']??'');
    if($memberNo===''||$name===''||$designation==='') throw new RuntimeException('Member ID, Full Name and Designation are required.');
    $phone=trim($_POST['phone']??'');$email=trim($_POST['email']??'');$address=trim($_POST['address']??'');$events=trim($_POST['events']??'');
    $joined=$_POST['joined_date']??date('Y-m-d');$valid=($_POST['valid_until']??'')?:null;$status=$_POST['status']??'active';$password=trim($_POST['password']??'');
    $custom=$_POST['custom']??[]; if(!is_array($custom))$custom=[];
    $notes=trim($_POST['notes']??''); if($notes!=='')$custom['notes']=$notes; else unset($custom['notes']);
    $photo=$member['photo']??null;
    $incomingFile=null;
    if(!empty($_FILES['photo']['name'])) $incomingFile=$_FILES['photo'];
    elseif(!empty($_FILES['photo_camera']['name'])) $incomingFile=$_FILES['photo_camera'];
    if($incomingFile){
      if(($incomingFile['error']??UPLOAD_ERR_OK)!==UPLOAD_ERR_OK) throw new RuntimeException('The selected photo could not be uploaded. Please try again.');
      if($incomingFile['size']>MAX_UPLOAD_BYTES) throw new RuntimeException('Photo is too large. Maximum allowed size is 3 MB.');
      $mime=(new finfo(FILEINFO_MIME_TYPE))->file($incomingFile['tmp_name']);
      $allowed=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
      if(!isset($allowed[$mime])) throw new RuntimeException('Only JPG, PNG or WebP photos are allowed.');
      $safe=preg_replace('/[^A-Za-z0-9_-]/','_',$memberNo);
      $new=$safe.'_'.bin2hex(random_bytes(6)).'.'.$allowed[$mime];
      if(!move_uploaded_file($incomingFile['tmp_name'],UPLOAD_DIR.$new)) throw new RuntimeException('Could not save the uploaded photo.');
      // Normalize every member photo to the fixed passport/ID ratio (4:5).
      if(function_exists('imagecreatefromjpeg')){
        $srcPath=UPLOAD_DIR.$new;
        $srcImg=null;
        if($mime==='image/jpeg') $srcImg=@imagecreatefromjpeg($srcPath);
        elseif($mime==='image/png') $srcImg=@imagecreatefrompng($srcPath);
        elseif($mime==='image/webp' && function_exists('imagecreatefromwebp')) $srcImg=@imagecreatefromwebp($srcPath);
        if($srcImg){
          $sw=imagesx($srcImg); $sh=imagesy($srcImg);
          $ratio=4/5; $cropW=$sw; $cropH=(int)round($sw/($ratio));
          if($cropH>$sh){ $cropH=$sh; $cropW=(int)round($sh*$ratio); }
          $sx=(int)max(0,($sw-$cropW)/2); $sy=(int)max(0,($sh-$cropH)/2);
          $dstW=480; $dstH=600; $dst=imagecreatetruecolor($dstW,$dstH);
          imagealphablending($dst,false); imagesavealpha($dst,true); $white=imagecolorallocatealpha($dst,255,255,255,0); imagefilledrectangle($dst,0,0,$dstW,$dstH,$white);
          imagecopyresampled($dst,$srcImg,0,0,$sx,$sy,$dstW,$dstH,$cropW,$cropH);
          imagejpeg($dst,$srcPath,90); imagedestroy($dst); imagedestroy($srcImg);
        }
      }
      $photo=$new;
    }
    if(!$id && empty($photo)) throw new RuntimeException('A member photo is required. Upload a photo or use the camera before saving.');
    $customJson=$custom?json_encode($custom,JSON_UNESCAPED_UNICODE):null;
    ensure_member_schema();
    $columns = member_table_columns();
    if($id){
      $set=[]; $params=[];
      $candidate = [
        'member_no'=>$memberNo,'name'=>$name,'designation'=>$designation,'phone'=>$phone,'email'=>$email,
        'address'=>$address,'events'=>$events,'photo'=>$photo,'status'=>$status,'joined_date'=>$joined,
        'valid_until'=>$valid,'custom_data'=>$customJson
      ];
      if($password!=='') $candidate['password_hash']=password_hash($password,PASSWORD_DEFAULT);
      foreach($candidate as $col=>$val){ if(isset($columns[$col])){ $set[]=$col.'=?'; $params[]=$val; } }
      if(!$set) throw new RuntimeException('No compatible member fields were found in the database.');
      $params[]=$id;
      db()->prepare('UPDATE members SET '.implode(',',$set).' WHERE id=?')->execute($params);
      audit('MEMBER_UPDATED',$memberNo);$ok='Member updated successfully.';
    }else{
      $verify=bin2hex(random_bytes(24));$hash=password_hash($password!==''?$password:$memberNo,PASSWORD_DEFAULT);
      $candidate = [
        'member_no'=>$memberNo,'name'=>$name,'designation'=>$designation,'phone'=>$phone,'email'=>$email,
        'address'=>$address,'events'=>$events,'photo'=>$photo,'status'=>$status,'joined_date'=>$joined,
        'valid_until'=>$valid,'verify_token'=>$verify,'password_hash'=>$hash,'custom_data'=>$customJson
      ];
      $cols=[];$marks=[];$params=[];
      foreach($candidate as $col=>$val){ if(isset($columns[$col])){ $cols[]=$col; $marks[]='?'; $params[]=$val; } }
      foreach(['member_no','name','designation','verify_token'] as $requiredCol){
        if(!isset($columns[$requiredCol])) throw new RuntimeException('The database members table is missing required column: '.$requiredCol.'.');
      }
      db()->prepare('INSERT INTO members('.implode(',',$cols).') VALUES('.implode(',',$marks).')')->execute($params);
      audit('MEMBER_CREATED',$memberNo);$ok='Member created successfully.';$id=(int)db()->lastInsertId();
    }
    $member=db()->query('SELECT * FROM members WHERE id='.(int)$id)->fetch();$custom=json_decode((string)($member['custom_data']??''),true)?:[];
  }catch(Throwable $e){error_log('Member form: '.$e->getMessage());$error='Could not save member. '.$e->getMessage();}
}
$defaultId='BAM-'.str_pad((string)(((int)db()->query('SELECT COUNT(*) FROM members')->fetchColumn())+1),4,'0',STR_PAD_LEFT);
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?= $id?'Edit':'Add' ?> BAM Member</title><link rel="stylesheet" href="../assets/admin.css?v=64"><link rel="manifest" href="/admin/manifest.json"><link rel="apple-touch-icon" href="/admin/apple-touch-icon.png"><script src="pwa.js?v=64" defer></script></head><body class="admin-page"><script>document.documentElement.dataset.adminTheme=<?=json_encode(get_setting('site_theme','night'))?>;</script>
<header class="topbar"><div class="container nav"><a class="brand" href="index.php"><img src="<?=get_setting('site_theme','night')==='day'?'../assets/bam-logo-day.png':'../assets/bam-logo.png'?>" alt="BAM"><strong>BAM ADMIN</strong></a><?php $base='';include __DIR__.'/_nav.php';?></div></header>
<main class="container"><div style="margin-bottom:20px"><div class="eyebrow">BAM // DIGITAL MEMBERSHIP</div><h1><?= $id?'Edit':'Add' ?> Member</h1></div>
<?php if($error):?><div class="alert alert-error"><?=e($error)?></div><?php endif;?><?php if($ok):?><div class="alert alert-ok"><?=e($ok)?></div><div class="admin-actions" style="margin-bottom:18px"><a class="btn btn-red" href="member_form.php">+ Add Another Member</a><a class="btn btn-light" href="../id.php?id=<?=urlencode($member['member_no'])?>" target="_blank">Open Digital ID</a></div><?php endif;?>
<form class="card" method="post" enctype="multipart/form-data"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="id" value="<?=e((string)$id)?>"><div class="form-grid">
<div class="field"><label>Member ID *</label><input name="member_no" required value="<?=e($member['member_no']??$defaultId)?>"></div><div class="field"><label>Full Name *</label><input name="name" required value="<?=e($member['name']??'')?>"></div><div class="field"><label>Designation *</label><input name="designation" required value="<?=e($member['designation']??'')?>"></div><div class="field"><label>Phone</label><input name="phone" value="<?=e($member['phone']??'')?>"></div><div class="field"><label>Email</label><input type="email" name="email" value="<?=e($member['email']??'')?>"></div><div class="field"><label>Status</label><select name="status"><?php foreach(['active','inactive','suspended','expired'] as $st):?><option value="<?=$st?>" <?=($member['status']??'active')===$st?'selected':''?>><?=strtoupper($st)?></option><?php endforeach;?></select></div>
<div class="field full"><label>Address</label><textarea name="address"><?=e($member['address']??'')?></textarea></div><div class="field full"><label>Events / Assignment</label><textarea name="events" placeholder="Events, functions or assignments to display on the ID"><?=e($member['events']??'')?></textarea></div>
<div class="field"><label>Joined Date</label><input type="date" name="joined_date" value="<?=e($member['joined_date']??date('Y-m-d'))?>"></div><div class="field"><label>Valid Until</label><input type="date" name="valid_until" value="<?=e($member['valid_until']??'')?>"></div>
<div class="field"><label>Member Login Password</label><input type="password" name="password"><div class="small muted">Default password for a new member is their Membership ID. Leave blank when editing to keep the existing password.</div></div><div class="field full">
<label>Member Photo <?=(!$id?'<span style="color:#ff5962">*</span>':'')?></label>
<input type="file" id="photoUpload" name="photo" accept="image/jpeg,image/png,image/webp" hidden <?=(!$id?'required':'')?>>
<input type="file" id="photoCamera" name="photo_camera" accept="image/jpeg,image/png,image/webp" capture="environment" hidden>
<div class="photo-tools">
  <button type="button" class="btn btn-red" id="choosePhotoBtn">Upload / Take Photo</button>
</div>
<div class="small muted">For a new member, a photo is required. Tap the button and choose <strong>Open File</strong> or <strong>Use Camera</strong>. No cropping is required.</div>
<div class="required-note" id="photoRequiredNote" <?=($id?'style="display:none"':'')?>>Photo required for new members.</div>
<img id="photoPreview" class="photo-preview" src="<?=!empty($member['photo'])?e(member_photo($member['photo'])):''?>" alt="Member photo preview" <?=empty($member['photo'])?'style="display:none"':''?>>
</div>
<?php foreach($fields as $f): if(in_array($f['field_key'],['member_no','designation','phone','email','address','events','joined_date','valid_until','status'],true)) continue; $key=$f['field_key']; ?><div class="field"><label><?=e($f['label'])?><?=((int)$f['active']?'':'')?></label><input name="custom[<?=e($key)?>]" value="<?=e((string)($custom[$key]??''))?>"></div><?php endforeach;?>
<div class="field full"><label>Internal Notes</label><textarea name="notes"><?=e((string)($custom['notes']??''))?></textarea></div></div><br><button class="btn btn-red">Save Member</button> <a class="btn btn-light" href="members.php">Cancel</a></form></main>
<div class="photo-choice-modal" id="photoChoiceModal" aria-hidden="true">
  <div class="photo-choice-panel" role="dialog" aria-modal="true" aria-labelledby="photoChoiceTitle">
    <h2 id="photoChoiceTitle">Add Member Photo</h2>
    <p>Choose how you want to add the member photo.</p>
    <div class="photo-choice-actions">
      <button type="button" class="btn btn-light" id="openFileChoice">Open File</button>
      <button type="button" class="btn btn-red" id="useCameraChoice">Use Camera</button>
    </div>
    <button type="button" class="photo-choice-cancel" id="photoChoiceCancel">Cancel</button>
  </div>
</div>
<script>
(function(){
  const upload=document.getElementById('photoUpload');
  const camera=document.getElementById('photoCamera');
  const choose=document.getElementById('choosePhotoBtn');
  const preview=document.getElementById('photoPreview');
  const note=document.getElementById('photoRequiredNote');
  const modal=document.getElementById('photoChoiceModal');
  const openFile=document.getElementById('openFileChoice');
  const useCamera=document.getElementById('useCameraChoice');
  const cancel=document.getElementById('photoChoiceCancel');
  const form=document.querySelector('form');
  const maxBytes=3*1024*1024;
  function showModal(){modal.classList.add('open');modal.setAttribute('aria-hidden','false')}
  function hideModal(){modal.classList.remove('open');modal.setAttribute('aria-hidden','true')}
  function previewFile(file){
    if(!file)return;
    if(file.size>maxBytes){alert('Photo is too large. Maximum allowed size is 3 MB.');return}
    if(!/^image\/(jpeg|png|webp)$/i.test(file.type)){alert('Only JPG, PNG or WebP photos are allowed.');return}
    const reader=new FileReader();
    reader.onload=e=>{preview.src=e.target.result;preview.style.display='block';if(note)note.style.display='none'};
    reader.onerror=()=>alert('Could not read the selected photo. Please try again.');
    reader.readAsDataURL(file);
  }
  choose?.addEventListener('click',showModal);
  cancel?.addEventListener('click',hideModal);
  modal?.addEventListener('click',e=>{if(e.target===modal)hideModal()});
  openFile?.addEventListener('click',()=>{hideModal();upload.click()});
  useCamera?.addEventListener('click',()=>{hideModal();camera.click()});
  upload?.addEventListener('change',e=>{if(e.target.files?.length) upload.setAttribute('required','required'); previewFile(e.target.files?.[0]);});
  camera?.addEventListener('change',e=>{if(e.target.files?.length) upload.removeAttribute('required'); previewFile(e.target.files?.[0]);});
  form?.addEventListener('submit',function(e){
    <?php if(!$id): ?>
    if(!upload.files.length&&!camera.files.length){e.preventDefault();if(note)note.style.display='block';alert('Please upload a member photo or use the camera before saving.');return}
    <?php endif; ?>
    const file=upload.files[0]||camera.files[0];
    if(file&&(file.size>maxBytes||!/^image\/(jpeg|png|webp)$/i.test(file.type))){e.preventDefault();alert('Please select a valid JPG, PNG or WebP photo up to 3 MB.')}
  });
})();
</script></body></html>