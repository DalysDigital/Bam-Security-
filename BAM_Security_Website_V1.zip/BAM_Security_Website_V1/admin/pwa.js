(function(){
  'use strict';
  const cap=(name,content)=>{let m=document.querySelector('meta[name="'+name+'"]');if(!m){m=document.createElement('meta');m.name=name;document.head.appendChild(m);}m.content=content;};
  cap('mobile-web-app-capable','yes');
  cap('apple-mobile-web-app-capable','yes');
  cap('apple-mobile-web-app-status-bar-style','black-translucent');
  cap('application-name','BAM Admin');

  /* Full-page skeleton: show first, then reveal the real server-rendered page quickly.
     DOMContentLoaded is the primary reveal point so images/fonts cannot leave a blocker over the UI. */
  const skeleton=document.createElement('div');
  skeleton.className='bam-admin-loading';
  skeleton.setAttribute('aria-hidden','true');
  skeleton.innerHTML='<div class="bam-admin-loading-grid"><div class="bam-admin-loading-logo"></div><div class="bam-admin-loading-line wide"></div><div class="bam-admin-loading-line"></div><div class="bam-admin-loading-line short"></div><div class="bam-admin-loading-cards"><i></i><i></i><i></i><i></i></div><div class="bam-admin-loading-panel"></div></div>';
  document.body.appendChild(skeleton);
  let skeletonHidden=false;
  const hideSkeleton=()=>{
    if(skeletonHidden)return;
    skeletonHidden=true;
    skeleton.classList.add('hide');
    setTimeout(()=>skeleton.remove(),360);
  };
  if(document.readyState==='loading'){
    document.addEventListener('DOMContentLoaded',()=>setTimeout(hideSkeleton,260),{once:true});
  }else setTimeout(hideSkeleton,260);
  window.addEventListener('load',()=>setTimeout(hideSkeleton,80),{once:true});
  setTimeout(hideSkeleton,1800);

  const isStandalone=window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone===true;
  let deferredPrompt=null;
  let installReady=false;
  const appButton=document.getElementById('adminAppInstallButton');

  function setInstallTitle(){
    if(!appButton)return;
    const title=isStandalone?'BAM Admin App is installed':'Install BAM Admin App';
    appButton.title=title; appButton.setAttribute('aria-label',title);
  }
  setInstallTitle();

  /* Capture the native install event. Chromium only exposes this after its own
     installability/engagement checks; the app cannot manufacture that event. */
  window.addEventListener('beforeinstallprompt',e=>{
    e.preventDefault(); deferredPrompt=e; installReady=true; setInstallTitle();
  });
  window.addEventListener('appinstalled',()=>{deferredPrompt=null;installReady=false;setInstallTitle();});

  function showInstallHelp(message){
    let box=document.getElementById('adminInstallHelp');
    if(!box){
      box=document.createElement('div'); box.id='adminInstallHelp'; box.className='admin-install-help';
      box.innerHTML='<div class="admin-install-help-card" role="dialog" aria-modal="true" aria-labelledby="adminInstallHelpTitle"><h3 id="adminInstallHelpTitle">Install BAM Admin</h3><p>Chrome controls when the native install prompt is available. The admin PWA is configured for <b>/admin/</b> only.</p><div class="install-status" id="adminInstallHelpText"></div><div class="admin-install-help-actions"><button type="button" class="btn btn-light" id="adminInstallHelpClose">Close</button></div></div>';
      document.body.appendChild(box);
      box.querySelector('#adminInstallHelpClose').addEventListener('click',()=>box.classList.remove('show'));
      box.addEventListener('click',e=>{if(e.target===box)box.classList.remove('show');});
    }
    box.querySelector('#adminInstallHelpText').textContent=message;
    box.classList.add('show');
  }

  appButton?.addEventListener('click',async()=>{
    if(isStandalone){showInstallHelp('BAM Admin is already installed on this device.');return;}
    if(deferredPrompt){
      try{deferredPrompt.prompt(); await deferredPrompt.userChoice;}catch(e){}
      deferredPrompt=null;installReady=false;setInstallTitle();return;
    }
    /* Do not send the user to Settings. Explain the browser-controlled state instead. */
    const ios=/iphone|ipad|ipod/i.test(navigator.userAgent);
    if(ios){
      showInstallHelp('On iPhone or iPad, open this admin page in Safari, tap Share, then choose “Add to Home Screen”. Chrome on iOS cannot trigger the native PWA install prompt.');
    }else{
      showInstallHelp('Chrome has not exposed the native install prompt yet. Keep this secure admin page open and interact with it; Chrome controls the install eligibility. Once eligible, this same button will open the native Install dialog.');
    }
  });

  /* Register immediately from the admin page so the service worker can control the app
     before Chromium evaluates installability. */
  if('serviceWorker' in navigator){
    navigator.serviceWorker.register('/admin/sw.js',{scope:'/admin/'}).then(reg=>{
      const update=document.createElement('div'); update.className='admin-pwa-update'; update.innerHTML='<div><strong>New BAM Admin version available</strong><span>Reload to use the latest secure version.</span></div><button type="button">Update</button>'; document.body.appendChild(update);
      let reloading=false;
      navigator.serviceWorker.addEventListener('controllerchange',()=>{if(!reloading){reloading=true;location.reload();}});
      update.querySelector('button').addEventListener('click',()=>{if(reg.waiting)reg.waiting.postMessage({type:'SKIP_WAITING'});else location.reload();});
      if(reg.waiting)update.classList.add('show');
      reg.addEventListener('updatefound',()=>{const nw=reg.installing;if(!nw)return;nw.addEventListener('statechange',()=>{if(nw.state==='installed'&&navigator.serviceWorker.controller)update.classList.add('show');});});
    }).catch(()=>{});
  }

  /* V64: password visibility control on every admin password field. */
  document.querySelectorAll('input[type="password"]').forEach(input=>{
    let wrap=input.closest('.password-wrap');
    if(!wrap){
      wrap=document.createElement('div'); wrap.className='password-wrap';
      input.parentNode.insertBefore(wrap,input); wrap.appendChild(input);
    }
    let btn=wrap.querySelector('.password-toggle');
    if(!btn){
      btn=document.createElement('button'); btn.type='button'; btn.className='password-toggle';
      btn.textContent='Show'; btn.setAttribute('aria-label','Show password'); btn.title='Show password';
      wrap.appendChild(btn);
    }
    if(btn.dataset.bound==='1')return;
    btn.dataset.bound='1';
    btn.addEventListener('click',()=>{
      const visible=input.type==='text'; input.type=visible?'password':'text';
      btn.textContent=visible?'Show':'Hide'; btn.setAttribute('aria-label',visible?'Show password':'Hide password'); btn.title=visible?'Show password':'Hide password';
    });
  });

  /* Warn before leaving a page with unsaved form edits. */
  let dirty=false;
  document.querySelectorAll('form').forEach(f=>{f.addEventListener('input',()=>dirty=true);f.addEventListener('change',()=>dirty=true);f.addEventListener('submit',()=>dirty=false);});
  window.addEventListener('beforeunload',e=>{if(dirty){e.preventDefault();e.returnValue='';}});

  /* Push permission remains strictly opt-in. */
  window.bamAdminEnablePush=async function(){
    if(!('Notification' in window)||!('serviceWorker' in navigator)||!('PushManager' in window)) throw new Error('Push notifications are not supported by this browser.');
    const reg=await navigator.serviceWorker.ready;
    const permission=await Notification.requestPermission();
    if(permission!=='granted') throw new Error('Notification permission was not granted.');
    const cfg=await fetch('/admin/push.php?action=config',{credentials:'same-origin',cache:'no-store'}).then(r=>r.json());
    if(!cfg.publicKey) throw new Error('Push notifications are not configured on the server yet.');
    let sub=await reg.pushManager.getSubscription();
    if(!sub)sub=await reg.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:urlBase64ToUint8Array(cfg.publicKey)});
    const tokenData=await fetch('/admin/push.php?action=csrf',{credentials:'same-origin',cache:'no-store'}).then(r=>r.json());
    const token=tokenData.csrf||'';
    const res=await fetch('/admin/push.php?action=subscribe',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json','X-CSRF-Token':token},body:JSON.stringify({subscription:sub.toJSON()})});
    if(!res.ok)throw new Error('Could not save the push subscription.');
    return sub;
  };
  function urlBase64ToUint8Array(base64String){const padding='='.repeat((4-base64String.length%4)%4),base64=(base64String+padding).replace(/-/g,'+').replace(/_/g,'/'),raw=atob(base64);return Uint8Array.from([...raw].map(c=>c.charCodeAt(0)));}
})();
