<?php
require_once __DIR__.'/../config/config.php';
admin_required();
header('Content-Type: application/json; charset=utf-8');
$action=$_GET['action']??'';
if($action==='config'){
    try{$cfg=ensure_pwa_config();echo json_encode(['ok'=>true,'publicKey'=>$cfg['public']]);}catch(Throwable $e){http_response_code(500);echo json_encode(['ok'=>false,'error'=>'Push configuration unavailable.']);}exit;
}
if($action==='csrf'){echo json_encode(['ok'=>true,'csrf'=>csrf_token()]);exit;}
$csrf=$_SERVER['HTTP_X_CSRF_TOKEN']??'';if(!hash_equals(csrf_token(),$csrf)){http_response_code(419);echo json_encode(['ok'=>false,'error'=>'Invalid CSRF token.']);exit;}
$raw=file_get_contents('php://input');$data=json_decode($raw,true)?:[];
if($action==='subscribe'){
    $sub=$data['subscription']??null;if(!is_array($sub)||empty($sub['endpoint'])||empty($sub['keys']['p256dh'])||empty($sub['keys']['auth'])){http_response_code(422);echo json_encode(['ok'=>false,'error'=>'Invalid subscription.']);exit;}
    $subs=pwa_get_subscriptions();$found=false;foreach($subs as &$item){if(($item['endpoint']??'')===$sub['endpoint']){$item=$sub;$item['updated_at']=date('c');$found=true;break;}}unset($item);if(!$found){$sub['created_at']=date('c');$subs[]=$sub;}pwa_save_subscriptions($subs);audit('PWA_PUSH_SUBSCRIBED');echo json_encode(['ok'=>true]);exit;
}
if($action==='unsubscribe'){
    $endpoint=(string)($data['endpoint']??'');$subs=array_values(array_filter(pwa_get_subscriptions(),fn($s)=>($s['endpoint']??'')!==$endpoint));pwa_save_subscriptions($subs);audit('PWA_PUSH_UNSUBSCRIBED');echo json_encode(['ok'=>true]);exit;
}
http_response_code(404);echo json_encode(['ok'=>false,'error'=>'Unknown action.']);
