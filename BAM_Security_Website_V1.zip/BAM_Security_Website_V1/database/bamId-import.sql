CREATE TABLE IF NOT EXISTS admins (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 username VARCHAR(80) NOT NULL UNIQUE,
 email VARCHAR(190) NOT NULL,
 password_hash VARCHAR(255) NOT NULL,
 active TINYINT(1) NOT NULL DEFAULT 1,
 last_login DATETIME NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS id_fields (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 field_key VARCHAR(80) NOT NULL UNIQUE,
 label VARCHAR(120) NOT NULL,
 active TINYINT(1) NOT NULL DEFAULT 1,
 on_card TINYINT(1) NOT NULL DEFAULT 1,
 public_verify TINYINT(1) NOT NULL DEFAULT 1,
 sort_order INT NOT NULL DEFAULT 0,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS members (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 member_no VARCHAR(80) NOT NULL UNIQUE,
 name VARCHAR(190) NOT NULL,
 designation VARCHAR(120) NULL,
 phone VARCHAR(40) NULL,
 email VARCHAR(190) NULL,
 address TEXT NULL,
 events TEXT NULL,
 photo VARCHAR(255) NULL,
 status ENUM('active','inactive','suspended','expired') NOT NULL DEFAULT 'active',
 joined_date DATE NULL,
 valid_until DATE NULL,
 verify_token VARCHAR(80) NOT NULL UNIQUE,
 password_hash VARCHAR(255) NULL,
 custom_data JSON NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 INDEX(status), INDEX(name), INDEX(member_no)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS invoices (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 invoice_no VARCHAR(80) NOT NULL UNIQUE,
 client_name VARCHAR(190) NOT NULL,
 client_email VARCHAR(190) NULL,
 client_phone VARCHAR(50) NULL,
 client_address TEXT NULL,
 invoice_date DATE NOT NULL,
 due_date DATE NULL,
 items JSON NOT NULL,
 subtotal DECIMAL(12,2) NOT NULL DEFAULT 0,
 tax_percent DECIMAL(6,2) NOT NULL DEFAULT 0,
 tax_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
 total DECIMAL(12,2) NOT NULL DEFAULT 0,
 notes TEXT NULL,
 status ENUM('draft','sent','paid','cancelled') NOT NULL DEFAULT 'draft',
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 INDEX(invoice_date), INDEX(status)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS letters (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 letter_no VARCHAR(80) NOT NULL UNIQUE,
 letter_date DATE NOT NULL,
 recipient_name VARCHAR(190) NOT NULL,
 recipient_org VARCHAR(190) NULL,
 recipient_address TEXT NULL,
 subject VARCHAR(255) NULL,
 body LONGTEXT NOT NULL,
 signatory VARCHAR(190) NULL,
 designation VARCHAR(190) NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT IGNORE INTO id_fields(field_key,label,active,on_card,public_verify,sort_order) VALUES
('member_no','Membership / ID No.',1,1,1,10),
('designation','Designation',1,1,1,20),
('phone','Phone',1,1,0,30),
('email','Email',1,0,0,40),
('address','Address',1,1,1,50),
('events','Events / Assignment',1,1,1,60),
('joined_date','Joined Date',1,0,1,70),
('valid_until','Valid Until',1,1,1,80),
('status','Status',1,1,1,90);


CREATE TABLE IF NOT EXISTS events (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 event_name VARCHAR(190) NOT NULL,
 event_type VARCHAR(120) NULL,
 client_name VARCHAR(190) NULL,
 location VARCHAR(255) NULL,
 event_date DATE NULL,
 start_time TIME NULL,
 end_time TIME NULL,
 personnel_required INT UNSIGNED NOT NULL DEFAULT 0,
 personnel_deployed INT UNSIGNED NOT NULL DEFAULT 0,
 status ENUM('planned','confirmed','ongoing','completed','cancelled') NOT NULL DEFAULT 'planned',
 notes TEXT NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 INDEX(event_date), INDEX(status)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS audit_logs (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 admin_id INT UNSIGNED DEFAULT NULL,
 action VARCHAR(120) NOT NULL,
 member_id VARCHAR(80) DEFAULT NULL,
 ip_address VARCHAR(45) DEFAULT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_audit_member(member_id),
 INDEX idx_audit_created(created_at)
) ENGINE=InnoDB;
