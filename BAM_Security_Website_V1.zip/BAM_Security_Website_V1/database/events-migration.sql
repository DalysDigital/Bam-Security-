CREATE TABLE IF NOT EXISTS events (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 event_name VARCHAR(190) NOT NULL,
 event_type VARCHAR(120) NULL,
 client_name VARCHAR(190) NULL,
 location VARCHAR(255) NULL,
 event_date DATE NULL,
 start_time TIME NULL,
 end_time TIME NULL,
 personnel_required INT UNSIGNED NOT NULL DEFAULT 0,
 personnel_deployed INT UNSIGNED NOT NULL DEFAULT 0,
 status ENUM('planned','confirmed','ongoing','completed','cancelled') NOT NULL DEFAULT 'planned',
 notes TEXT NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 INDEX(event_date), INDEX(status)
) ENGINE=InnoDB;
