-- V47 legacy letters-table compatibility migration.
-- Run only if automatic ALTER is blocked by the hosting account.
ALTER TABLE letters ADD COLUMN recipient_address TEXT NULL;
ALTER TABLE letters ADD COLUMN subject VARCHAR(500) NULL;
ALTER TABLE letters ADD COLUMN body_html MEDIUMTEXT NULL;
ALTER TABLE letters ADD COLUMN closing_text VARCHAR(190) NOT NULL DEFAULT 'Thank you';
ALTER TABLE letters ADD COLUMN signature_caption VARCHAR(190) NOT NULL DEFAULT 'Yours faithfully';
ALTER TABLE letters ADD COLUMN signatory_name VARCHAR(190) NOT NULL DEFAULT 'Junestar Kharbuli';
ALTER TABLE letters ADD COLUMN signatory_title VARCHAR(190) NOT NULL DEFAULT 'PRESIDENT';
ALTER TABLE letters ADD COLUMN show_letter_no TINYINT(1) NOT NULL DEFAULT 1;
ALTER TABLE letters ADD COLUMN show_date TINYINT(1) NOT NULL DEFAULT 1;
ALTER TABLE letters ADD COLUMN status VARCHAR(20) NOT NULL DEFAULT 'draft';
ALTER TABLE letters ADD COLUMN updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
UPDATE letters SET body_html=body WHERE (body_html IS NULL OR body_html='') AND body IS NOT NULL;
UPDATE letters SET signatory_name=signatory WHERE (signatory_name IS NULL OR signatory_name='') AND signatory IS NOT NULL;
UPDATE letters SET signatory_title=designation WHERE (signatory_title IS NULL OR signatory_title='') AND designation IS NOT NULL;
