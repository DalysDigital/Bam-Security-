-- BAM V20 safe migration for an existing BAM database
-- Select the target BAM database in phpMyAdmin before running.
CREATE TABLE IF NOT EXISTS audit_logs (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 admin_id INT UNSIGNED DEFAULT NULL,
 action VARCHAR(120) NOT NULL,
 member_id VARCHAR(80) DEFAULT NULL,
 ip_address VARCHAR(45) DEFAULT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_audit_member(member_id),
 INDEX idx_audit_created(created_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS invoices (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 invoice_no VARCHAR(80) NOT NULL UNIQUE,
 client_name VARCHAR(190) NOT NULL,
 client_email VARCHAR(190) NULL,
 client_phone VARCHAR(50) NULL,
 client_address TEXT NULL,
 invoice_date DATE NOT NULL,
 due_date DATE NULL,
 items JSON NOT NULL,
 subtotal DECIMAL(12,2) NOT NULL DEFAULT 0,
 tax_percent DECIMAL(6,2) NOT NULL DEFAULT 0,
 tax_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
 total DECIMAL(12,2) NOT NULL DEFAULT 0,
 notes TEXT NULL,
 status ENUM('draft','sent','paid','cancelled') NOT NULL DEFAULT 'draft',
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 INDEX(invoice_date), INDEX(status)
) ENGINE=InnoDB;
