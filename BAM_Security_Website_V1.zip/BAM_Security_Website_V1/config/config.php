<?php
declare(strict_types=1);

/*
 * BAM - Bouncer Association of Meghalaya
 * InfinityFree deployment configuration
 */

// Admin sessions are intentionally non-persistent and expire after 60 minutes of inactivity.
ini_set('session.gc_maxlifetime', '3600');
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'secure' => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
    'httponly' => true,
    'samesite' => 'Lax',
]);
session_start();

const ADMIN_IDLE_TIMEOUT = 3600;

const DB_HOST = '__DB_HOST__';
const DB_PORT = '__DB_PORT__';
const DB_NAME = '__DB_NAME__';
const DB_USER = '__DB_USER__';
const DB_PASS = '__DB_PASS__';

const APP_NAME = 'Bouncer Association of Meghalaya';
const APP_SHORT = 'BAM';
const APP_URL = '__APP_URL__';

const UPLOAD_DIR = __DIR__ . '/../uploads/';
const LOG_DIR = __DIR__ . '/../logs/';
const MAX_UPLOAD_BYTES = 3 * 1024 * 1024;

date_default_timezone_set('Asia/Kolkata');

/*
 * Production-safe error handling:
 * Fatal PHP errors are logged instead of being displayed to visitors.
 */
ini_set('display_errors', '0');
ini_set('log_errors', '1');
ini_set('error_log', LOG_DIR . 'php-error.log');

function db(): PDO {
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }

    $dsn = 'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' .
           DB_NAME . ';charset=utf8mb4';

    $pdo = new PDO($dsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);

    return $pdo;
}

function e(?string $value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function redirect(string $url): never {
    header('Location: ' . $url);
    exit;
}

function csrf_token(): string {
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function verify_csrf(): void {
    if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) {
        http_response_code(419);
        exit('Invalid CSRF token.');
    }
}

function admin_required(): void {
    if (empty($_SESSION['admin_id'])) {
        redirect('login.php');
    }
    $last = (int)($_SESSION['admin_last_activity'] ?? 0);
    if ($last > 0 && (time() - $last) >= ADMIN_IDLE_TIMEOUT) {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'] ?? '', (bool)$params['secure'], (bool)$params['httponly']);
        }
        session_destroy();
        setcookie('bam_admin_session', '', time() - 3600, '/');
        redirect('login.php?timeout=1');
    }
    $_SESSION['admin_last_activity'] = time();
    sync_expired_members();
    setcookie('bam_admin_session', '1', [
        'expires' => time() + ADMIN_IDLE_TIMEOUT,
        'path' => '/',
        'secure' => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
}

function sync_expired_members(): void {
    static $done = false;
    if ($done) return;
    try {
        $pdo = db();
        $cols = member_table_columns();
        if (isset($cols['valid_until']) && isset($cols['status'])) {
            $pdo->exec("UPDATE members SET status='expired' WHERE valid_until IS NOT NULL AND valid_until<>'' AND valid_until < CURDATE() AND LOWER(status) IN ('active','inactive')");
        }
    } catch (Throwable $e) { error_log('Expired membership sync: '.$e->getMessage()); }
    $done = true;
}

function member_required(): void {
    if (empty($_SESSION['member_id'])) {
        redirect('login.php');
    }
}

function member_photo(?string $filename): string {
    if (!$filename) {
        return APP_URL . '/assets/default-member.svg';
    }
    return APP_URL . '/uploads/' . rawurlencode($filename);
}

function member_by_id(string $memberId): ?array {
    sync_expired_members();
    $stmt = db()->prepare('SELECT * FROM members WHERE member_no = ? LIMIT 1');
    $stmt->execute([$memberId]);
    return $stmt->fetch() ?: null;
}

function member_table_columns(): array {
    static $columns = null;
    if ($columns !== null) return $columns;
    $columns = [];
    $rows = db()->query("SHOW COLUMNS FROM members")->fetchAll();
    foreach ($rows as $row) $columns[$row['Field']] = true;
    return $columns;
}

function ensure_member_schema(): void {
    static $done = false;
    if ($done) return;
    $pdo = db();
    $columns = member_table_columns();
    $missing = [];
    if (!isset($columns['password_hash'])) $missing[] = "ADD COLUMN password_hash VARCHAR(255) NULL";
    if (!isset($columns['custom_data'])) $missing[] = "ADD COLUMN custom_data TEXT NULL";
    if ($missing) {
        $pdo->exec('ALTER TABLE members ' . implode(', ', $missing));
    }
    $done = true;
}

function ensure_member_password_column(): void {
    static $done = false;
    if ($done) return;
    try {
        $pdo = db();
        $check = $pdo->query("SHOW COLUMNS FROM members LIKE 'password_hash'");
        if (!$check->fetch()) {
            $pdo->exec("ALTER TABLE members ADD COLUMN password_hash VARCHAR(255) NULL AFTER verify_token");
        }
        $done = true;
    } catch (Throwable $e) {
        error_log('Member password migration: ' . $e->getMessage());
        throw $e;
    }
}

function ensure_audit_table(): void {
    static $done=false;
    if($done) return;
    db()->exec("CREATE TABLE IF NOT EXISTS audit_logs (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        admin_id INT UNSIGNED DEFAULT NULL,
        action VARCHAR(120) NOT NULL,
        member_id VARCHAR(80) DEFAULT NULL,
        ip_address VARCHAR(45) DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_audit_member(member_id),
        INDEX idx_audit_created(created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $done=true;
}

function ensure_invoice_table(): void {
    static $done=false;
    if($done) return;
    db()->exec("CREATE TABLE IF NOT EXISTS invoices (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        invoice_no VARCHAR(80) NOT NULL UNIQUE,
        client_name VARCHAR(190) NOT NULL,
        client_email VARCHAR(190) NULL,
        client_phone VARCHAR(50) NULL,
        client_address TEXT NULL,
        invoice_date DATE NOT NULL,
        due_date DATE NULL,
        items JSON NOT NULL,
        subtotal DECIMAL(12,2) NOT NULL DEFAULT 0,
        tax_percent DECIMAL(6,2) NOT NULL DEFAULT 0,
        tax_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
        total DECIMAL(12,2) NOT NULL DEFAULT 0,
        notes TEXT NULL,
        status ENUM('draft','sent','paid','cancelled') NOT NULL DEFAULT 'draft',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX(invoice_date), INDEX(status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $done=true;
}

function next_invoice_no(): string {
    ensure_invoice_table();
    $n=(int)db()->query('SELECT COUNT(*) FROM invoices')->fetchColumn()+1;
    do { $no='BAM-INV-'.date('Y').'-'.str_pad((string)$n,4,'0',STR_PAD_LEFT); $s=db()->prepare('SELECT id FROM invoices WHERE invoice_no=?'); $s->execute([$no]); $n++; } while($s->fetch());
    return $no;
}



function ensure_letters_table(): void {
    static $done=false;
    if($done) return;

    $pdo=db();
    $exists=$pdo->query("SHOW TABLES LIKE 'letters'")->fetchColumn();

    if(!$exists){
        $pdo->exec("CREATE TABLE letters (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            letter_no VARCHAR(80) NULL,
            letter_date DATE NULL,
            recipient_address TEXT NULL,
            subject VARCHAR(500) NULL,
            body_html MEDIUMTEXT NULL,
            closing_text VARCHAR(190) NOT NULL DEFAULT 'Thank you',
            signature_caption VARCHAR(190) NOT NULL DEFAULT 'Yours faithfully',
            signatory_name VARCHAR(190) NOT NULL DEFAULT 'Junestar Kharbuli',
            signatory_title VARCHAR(190) NOT NULL DEFAULT 'PRESIDENT',
            signature_file VARCHAR(255) NULL,
            show_letter_no TINYINT(1) NOT NULL DEFAULT 1,
            show_date TINYINT(1) NOT NULL DEFAULT 1,
            status VARCHAR(20) NOT NULL DEFAULT 'draft',
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_letter_date(letter_date), INDEX idx_letter_status(status)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $done=true;
        return;
    }

    // V46 originally shipped against a legacy letters table. Upgrade it in-place
    // instead of relying on CREATE TABLE IF NOT EXISTS (which does not migrate it).
    $cols=[];
    foreach($pdo->query('SHOW COLUMNS FROM letters')->fetchAll() as $c) $cols[$c['Field']]=true;

    $add=[
        'recipient_address'=>"ALTER TABLE letters ADD COLUMN recipient_address TEXT NULL",
        'subject'=>"ALTER TABLE letters ADD COLUMN subject VARCHAR(500) NULL",
        'body_html'=>"ALTER TABLE letters ADD COLUMN body_html MEDIUMTEXT NULL",
        'closing_text'=>"ALTER TABLE letters ADD COLUMN closing_text VARCHAR(190) NOT NULL DEFAULT 'Thank you'",
        'signature_caption'=>"ALTER TABLE letters ADD COLUMN signature_caption VARCHAR(190) NOT NULL DEFAULT 'Yours faithfully'",
        'signatory_name'=>"ALTER TABLE letters ADD COLUMN signatory_name VARCHAR(190) NOT NULL DEFAULT 'Junestar Kharbuli'",
        'signatory_title'=>"ALTER TABLE letters ADD COLUMN signatory_title VARCHAR(190) NOT NULL DEFAULT 'PRESIDENT'",
        'signature_file'=>"ALTER TABLE letters ADD COLUMN signature_file VARCHAR(255) NULL",
        'show_letter_no'=>"ALTER TABLE letters ADD COLUMN show_letter_no TINYINT(1) NOT NULL DEFAULT 1",
        'show_date'=>"ALTER TABLE letters ADD COLUMN show_date TINYINT(1) NOT NULL DEFAULT 1",
        'status'=>"ALTER TABLE letters ADD COLUMN status VARCHAR(20) NOT NULL DEFAULT 'draft'",
        'updated_at'=>"ALTER TABLE letters ADD COLUMN updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"
    ];
    foreach($add as $col=>$sql){
        if(empty($cols[$col])){
            $pdo->exec($sql);
            $cols[$col]=true;
        }
    }

    // Preserve useful content from the older schema where those columns exist.
    if(isset($cols['body'])) $pdo->exec("UPDATE letters SET body_html=body WHERE (body_html IS NULL OR body_html='') AND body IS NOT NULL");
    if(isset($cols['signatory'])) $pdo->exec("UPDATE letters SET signatory_name=signatory WHERE (signatory_name IS NULL OR signatory_name='') AND signatory IS NOT NULL");
    if(isset($cols['designation'])) $pdo->exec("UPDATE letters SET signatory_title=designation WHERE (signatory_title IS NULL OR signatory_title='') AND designation IS NOT NULL");

    $done=true;
}

function next_letter_no(): string {
    ensure_letters_table();
    $n=(int)db()->query('SELECT COUNT(*) FROM letters')->fetchColumn()+1;
    do { $no='BAM/LET/'.date('Y').'/'.str_pad((string)$n,4,'0',STR_PAD_LEFT); $s=db()->prepare('SELECT id FROM letters WHERE letter_no=?'); $s->execute([$no]); $n++; } while($s->fetch());
    return $no;
}

function ensure_events_table(): void {
    static $done = false;
    if ($done) return;
    db()->exec("CREATE TABLE IF NOT EXISTS events (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        event_name VARCHAR(190) NOT NULL,
        event_type VARCHAR(120) DEFAULT NULL,
        client_name VARCHAR(190) DEFAULT NULL,
        location VARCHAR(255) DEFAULT NULL,
        event_date DATE DEFAULT NULL,
        start_time TIME DEFAULT NULL,
        end_time TIME DEFAULT NULL,
        personnel_required INT UNSIGNED NOT NULL DEFAULT 0,
        personnel_deployed INT UNSIGNED NOT NULL DEFAULT 0,
        status ENUM('planned','confirmed','ongoing','completed','cancelled') NOT NULL DEFAULT 'planned',
        notes TEXT DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_event_date(event_date),
        INDEX idx_event_status(status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $done = true;
}


function ensure_admins_table(): void {
    static $done=false; if($done) return;
    $pdo=db();
    $pdo->exec("CREATE TABLE IF NOT EXISTS admins (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(80) NOT NULL,
        email VARCHAR(190) NOT NULL,
        password_hash VARCHAR(255) NOT NULL,
        active TINYINT(1) NOT NULL DEFAULT 1,
        last_login DATETIME NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $cols=[]; foreach($pdo->query('SHOW COLUMNS FROM admins')->fetchAll() as $c) $cols[$c['Field']]=true;
    $adds=[];
    if(!isset($cols['username'])) $adds[]="ADD COLUMN username VARCHAR(80) NULL";
    if(!isset($cols['email'])) $adds[]="ADD COLUMN email VARCHAR(190) NULL";
    if(!isset($cols['password_hash'])) $adds[]="ADD COLUMN password_hash VARCHAR(255) NULL";
    if(!isset($cols['active'])) $adds[]="ADD COLUMN active TINYINT(1) NOT NULL DEFAULT 1";
    if(!isset($cols['last_login'])) $adds[]="ADD COLUMN last_login DATETIME NULL";
    if(!isset($cols['created_at'])) $adds[]="ADD COLUMN created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP";
    if($adds) foreach($adds as $sql){ try{$pdo->exec('ALTER TABLE admins '.$sql);}catch(Throwable $e){error_log('Admin schema migration: '.$e->getMessage());} }
    $done=true;
}

function ensure_settings_table(): void {
    static $done = false;
    if ($done) return;
    db()->exec("CREATE TABLE IF NOT EXISTS site_settings (
        setting_key VARCHAR(100) PRIMARY KEY,
        setting_value TEXT NULL,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $defaults = [
        'president_name' => 'Junestar Kharbuli',
        'president_signature' => '',
        'invoice_title' => 'BILL',
        'invoice_logo' => 'assets/bam-logo.png',
        'invoice_address' => 'Malki Point - 793001',
        'invoice_phone' => '+91 70056 68453 / +91 70058 61828',
        'invoice_email' => 'e2kharkongor@gmail.com',
        'invoice_instagram' => 'meghalaya_bouncer',
        'invoice_thank_you' => 'THANK YOU!',
        'invoice_footer' => 'Bouncer Association of Meghalaya • Safety & Security',
        'invoice_signature_caption' => 'Yours faithfully',
        'invoice_currency' => '₹',
        'invoice_words_label' => 'Amount in Words:',
        'id_logo' => 'assets/bam-logo.png',
        'id_front_footer' => 'BAM • Professional Security • Meghalaya',
        'id_front_bg' => '#090909',
        'id_back_bg' => '#090909',
        'id_accent' => '#e30613',
        'id_size' => '80x100',
        'id_back_title' => 'MEMBERSHIP VERIFICATION',
        'id_back_note' => "Scan the QR code to verify this member's BAM registration and current membership status.",
        'id_back_footer' => 'Official BAM Digital ID',
        'verify_title' => 'Verification Confirmed.',
        'verify_subtitle' => 'Verified BAM Member',
        'verify_prompt' => 'Public member search is disabled. Verification is available through the QR code printed on an official BAM Digital ID.',
        'verify_invalid' => 'No valid BAM membership record was found for this verification link.',
        'verify_show_member_id' => '1',
        'verify_show_designation' => '1',
        'verify_show_phone' => '0',
        'verify_show_email' => '0',
        'verify_show_address' => '0',
        'verify_show_events' => '0',
        'verify_show_joined_date' => '0',
        'verify_show_valid_until' => '1',
        'verify_show_status' => '1',
        'verify_footer' => 'BAM Digital ID Verification • Official QR verification',
        'site_theme' => 'night',
        'letterhead_image' => 'assets/bam-letterhead.png',
        'letter_default_no' => 'BAM/LET/'.date('Y').'/0001',
        'letter_show_no' => '1',
        'letter_show_date' => '1',
        'letter_default_closing' => 'Thank you',
        'letter_default_signature_caption' => 'Yours faithfully',
        'letter_default_signatory_name' => 'Junestar Kharbuli',
        'letter_default_signatory_title' => 'PRESIDENT',
        'letter_default_signature_file' => '',
        'verify_public_search' => '0',
        'verify_badge_style' => 'green'
    ];
    $st = db()->prepare('INSERT IGNORE INTO site_settings(setting_key,setting_value) VALUES(?,?)');
    foreach ($defaults as $k=>$v) $st->execute([$k,$v]);
    $done = true;
}

function get_setting(string $key, string $default=''): string {
    ensure_settings_table();
    $st=db()->prepare('SELECT setting_value FROM site_settings WHERE setting_key=? LIMIT 1');
    $st->execute([$key]);
    $v=$st->fetchColumn();
    return $v===false ? $default : (string)$v;
}

function set_setting(string $key, string $value): void {
    ensure_settings_table();
    db()->prepare('INSERT INTO site_settings(setting_key,setting_value) VALUES(?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)')->execute([$key,$value]);
}

function ensure_id_fields_table(): void {
    static $done=false; if($done) return;
    db()->exec("CREATE TABLE IF NOT EXISTS id_fields (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, field_key VARCHAR(80) NOT NULL UNIQUE,
        label VARCHAR(120) NOT NULL, active TINYINT(1) NOT NULL DEFAULT 1,
        on_card TINYINT(1) NOT NULL DEFAULT 1, public_verify TINYINT(1) NOT NULL DEFAULT 1,
        sort_order INT NOT NULL DEFAULT 0, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $defaults=[['member_no','Membership / ID No.',1,1,1,10],['designation','Designation',1,1,1,20],['phone','Phone',1,1,0,30],['email','Email',1,0,0,40],['address','Address',1,0,1,50],['events','Events / Assignment',1,1,1,60],['joined_date','Joined Date',1,0,1,70],['valid_until','Valid Until',1,1,1,80],['status','Status',1,1,1,90]];
    $st=db()->prepare('INSERT IGNORE INTO id_fields(field_key,label,active,on_card,public_verify,sort_order) VALUES(?,?,?,?,?,?)');
    foreach($defaults as $d)$st->execute($d); $done=true;
}

function audit(string $action, ?string $memberId = null): void {
    try {
        ensure_audit_table();
        $stmt = db()->prepare(
            'INSERT INTO audit_logs (admin_id, action, member_id, ip_address)
             VALUES (?, ?, ?, ?)'
        );
        $stmt->execute([
            $_SESSION['admin_id'] ?? null,
            $action,
            $memberId,
            $_SERVER['REMOTE_ADDR'] ?? null
        ]);
    } catch (Throwable $e) {
        error_log('Audit log error: ' . $e->getMessage());
    }
}

function ensure_frontend_content_table(): void {
    static $done = false;
    if ($done) return;
    db()->exec("CREATE TABLE IF NOT EXISTS frontend_gallery (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(190) NOT NULL DEFAULT '',
        image VARCHAR(255) NOT NULL,
        alt_text VARCHAR(255) NOT NULL DEFAULT '',
        sort_order INT NOT NULL DEFAULT 0,
        active TINYINT(1) NOT NULL DEFAULT 1,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_gallery_active(active), INDEX idx_gallery_sort(sort_order)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $defaults = [
        'hero_title'=>'Bouncer Association of Meghalaya',
        'hero_lead'=>'Bouncer Association of Meghalaya provides trained and professional bouncers and security personnel for events, functions, concerts, movie shows, weddings, festivals, VIP events and large crowd gatherings across Meghalaya. Our team focuses on crowd management, access control, event safety and maintaining a secure and orderly environment for guests, organizers and the public.',
        'hero_established'=>'2004','hero_experience'=>'20+','hero_professionals'=>'500+',
        'hero_established_label'=>'Established','hero_experience_label'=>'Years Experience','hero_professionals_label'=>'Professionals',
        'hero_status'=>'AVAILABLE FOR ENQUIRIES','hero_location'=>'MEGHALAYA',
        'nav_about'=>'About','nav_services'=>'Services','nav_capabilities'=>'Capabilities','nav_gallery'=>'Gallery','nav_contact'=>'Contact','nav_call'=>'CALL','hero_button1'=>'Request Security','hero_button2'=>'View Services','hero_meta_label'=>'SCROLL TO EXPLORE','contact_phone'=>'+917005668453','contact_email'=>'e2kharkongor@gmail.com','contact_whatsapp'=>'917005668453','contact_instagram'=>'meghalaya_bouncer',
        'about_heading'=>'Professional Security for a Safer Meghalaya','about_title'=>'Trained. Disciplined. Professional.',
        'about_p1'=>'Established in 2004, the Bouncers Association of Meghalaya (BAM) is a non-profit organization representing and regulating the bouncer industry in Meghalaya.',
        'about_p2'=>'BAM provides disciplined security personnel and crowd-management support with a focus on preparedness, professionalism, conflict resolution, emergency response and responsible conduct.',
        'about_pill1'=>'DISCIPLINE','about_pill2'=>'READINESS','about_pill3'=>'TRUST',
        'why_title'=>'Calm under pressure.','why_text'=>'From concerts and festivals to corporate functions, private gatherings and public events, BAM brings structured security operations to every assignment.',
        'why_stat1'=>'500+','why_stat1_label'=>'Professional Personnel','why_stat2'=>'5K+','why_stat2_label'=>'Events Supported','why_stat3'=>'20+','why_stat3_label'=>'Years of Experience',
        'services_heading'=>'Our Security Services','services_intro'=>'Choose the service that matches your requirement, then send BAM a structured enquiry in seconds.',
        'service1_title'=>'Event Security','service1_text'=>'Professional security personnel for private events, venues and large gatherings, with access control and guest management support.','service1_tag'=>'EVENT / VENUE SECURITY',
        'service2_title'=>'Crowd Control & Crowd Management','service2_text'=>'Structured crowd control, crowd management, access control and orderly movement for busy public and private events.','service2_tag'=>'CROWD MANAGEMENT',
        'service3_title'=>'Concert, Movie Show & Festival Security','service3_text'=>'Security support for concerts, music shows, movie shows, theatres, festivals and public entertainment events.','service3_tag'=>'EVENT SECURITY',
        'service4_title'=>'Wedding, Function, VIP & Celebrity Security','service4_text'=>'Trained personnel for weddings, functions, VIP and celebrity events, private events, guest management and secure venues.','service4_tag'=>'PROTECTION SERVICES',
        'services_additional_title'=>'Security for Events, Concerts & Large Gatherings','services_additional'=>'Private Event Security, Venue Security, Access Control, Guest Management, Large Gathering Security, Personal Protection, Commercial Security and Transport Security.',
        'cap_heading'=>'Events We Cover','cap_intro'=>'Plan the operation before the doors open. BAM can structure personnel and responsibilities around your venue, audience and schedule.',
        'cap1_title'=>'Concerts & Music Shows','cap1_text'=>'Security support for concerts, music shows and major entertainment events.',
        'cap2_title'=>'Movie Shows & Weddings','cap2_text'=>'Professional security for movie shows, weddings and private functions.',
        'cap3_title'=>'Festivals & Public Events','cap3_text'=>'Festival security, cultural events, sports events and large public gatherings.',
        'cap4_title'=>'VIP & Celebrity Events','cap4_text'=>'Trained personnel for VIP events, celebrity events and controlled access environments.',
        'events_list'=>'Concerts, Music Shows, Movie Shows, Weddings, Private Functions, Corporate Events, Festivals, Cultural Events, Political & Public Gatherings, Sports Events, College & School Events, VIP Events, Celebrity Events and Large Public Gatherings.',
        'journey_heading'=>'Why Choose Bouncer Association of Meghalaya','journey_intro'=>'BAM has supported artists, festivals, sports events, television productions, movies and music events.',
        'timeline1_label'=>'2004','timeline1_title'=>'Trained. Disciplined. Professional.','timeline1_text'=>'BAM begins its journey with a vision to elevate professional security standards in Meghalaya.',
        'timeline2_label'=>'EVENTS','timeline2_title'=>'Music & festivals','timeline2_text'=>'Fire House, MLTR, Mr. Big, Sunburn, Autumn Festival, NH7 Weekender, Cherry Blossom Festival, Hills Festival, Hoobastank, Vengaboys, Jonas Blue, Sanam, Jay Sean and more.',
        'timeline3_label'=>'SPORTS','timeline3_title'=>'Major sporting events','timeline3_text'=>'Meghalaya Games, Northeast Games, Durand Cup 2024, South Asian Games and All India Arm Wrestling Competition.',
        'timeline4_label'=>'MEDIA','timeline4_title'=>'Film & television','timeline4_text'=>'Rock On 2, MTV Roadies 2018 and other Indian reality shows, movies and music videos.',
        'gallery_heading'=>'Security in action.','gallery_intro'=>'Selected BAM field and event imagery from the supplied website assets.','gallery_console1'=>'VISUAL SYSTEMS ONLINE','gallery_console2'=>'SWIPE / CLICK TO SCAN',
        'story_title'=>'About Us','story_heading'=>'Security for Events, Concerts & Large Gatherings','story_p1'=>'BAM was founded with a vision to elevate the standard of security services in the region. Starting with a small group of dedicated professionals, the organization built a reputation around training, discipline and commitment.','story_p2'=>'Today, BAM continues to expand its services while keeping the same focus: professional people, clear responsibilities and a secure environment for clients and the public.',
        'vision_title'=>'Professional Event Security','vision_big'=>'Secure environments where people can gather, celebrate and thrive.','vision_text'=>'BAM aspires to be a leading security service provider in Meghalaya, recognized for safety, professionalism and excellence.',
        'mission_big'=>'Professional, reliable and discreet security solutions.','mission_text'=>'Through training, integrity and preparedness, BAM strives to protect and serve with high standards.',
        'join_heading'=>'Join the Bouncer Association of Meghalaya','join_text'=>'Tell us what you are planning, where it is happening and what support you need. BAM will receive your enquiry through the channel you choose.',
        'contact_heading'=>'Contact Us','contact_text'=>'Complete the secure enquiry form below and choose WhatsApp, email, SMS or a direct call. Your enquiry is prepared locally on your device and sent only through the channel you select.',
        'contact_form_title'=>'Tell us what you need.','contact_form_label'=>'SECURE ENQUIRY','contact_note'=>'Your message stays on your device until you choose a channel. No third-party form server is required.',
        'footer_text'=>'Bouncers Association of Meghalaya. All rights reserved.','footer_back'=>'BACK TO TOP ↑',
        'site_title'=>'Bouncer Association of Meghalaya | Professional Event Security Services','site_description'=>'Bouncer Association of Meghalaya provides trained and professional bouncers and security personnel for events, concerts, movie shows, functions, weddings, festivals, VIP events and large crowd gatherings across Meghalaya.',
        'hero_image'=>'assets/page-03-image-01.jpeg','feature_image'=>'assets/page-04-image-02.jpeg','story_image'=>'assets/page-12-image-01.jpeg','frontend_logo_day'=>'assets/bam-logo-day.png','frontend_logo_night'=>'assets/bam-logo-night-glossy.png',
        'font_heading'=>'Space Grotesk','font_body'=>'Inter',
        'day_bg'=>'#f5f7fa','day_text'=>'#111827','day_muted'=>'#5b6470','day_panel'=>'rgba(255,255,255,.78)','day_line'=>'rgba(15,23,42,.14)','day_accent'=>'#e30613','day_accent2'=>'#b9000b',
        'night_bg'=>'#050505','night_text'=>'#f5f5f2','night_muted'=>'#969696','night_panel'=>'rgba(255,255,255,.055)','night_line'=>'rgba(255,255,255,.12)','night_accent'=>'#e30613','night_accent2'=>'#ff3340'
    ];
    $st=db()->prepare('INSERT IGNORE INTO site_settings(setting_key,setting_value) VALUES(?,?)');
    foreach($defaults as $k=>$v) $st->execute([$k,$v]);
    $count=(int)db()->query('SELECT COUNT(*) FROM frontend_gallery')->fetchColumn();
    if($count===0){
        $items=[
            ['Field Operations','assets/page-05-image-01.jpeg','Bouncer security at a concert in Meghalaya',10],
            ['Crowd Management','assets/page-06-image-01.jpeg','Security team managing a large crowd in Meghalaya',20],
            ['Event Security','assets/page-08-image-01.jpeg','Crowd management and event security services in Meghalaya',30],
            ['Professional Bouncers','assets/page-09-image-02.jpeg','Professional bouncers providing event security in Meghalaya',40],
            ['Large Gathering','assets/page-10-image-01.jpeg','Security team managing a large crowd in Meghalaya',50]
        ];
        $ins=db()->prepare('INSERT INTO frontend_gallery(title,image,alt_text,sort_order,active) VALUES(?,?,?,?,1)');
        foreach($items as $it)$ins->execute($it);
    }
    $done=true;
}

function frontend_settings(): array {
    ensure_frontend_content_table();
    $rows=db()->query('SELECT setting_key,setting_value FROM site_settings')->fetchAll();
    $out=[]; foreach($rows as $r)$out[$r['setting_key']]=$r['setting_value'];
    return $out;
}

function frontend_gallery(bool $activeOnly=true): array {
    ensure_frontend_content_table();
    $sql='SELECT * FROM frontend_gallery'.($activeOnly?' WHERE active=1':'').' ORDER BY sort_order ASC,id ASC';
    return db()->query($sql)->fetchAll();
}

/* Admin PWA / Web Push helpers. These use existing site_settings rows; no new SQL table/import is required. */
function pwa_base64url(string $data): string {
    return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}
function pwa_base64url_decode(string $data): string {
    $data=strtr($data,'-_','+/');
    return base64_decode($data . str_repeat('=',(4-strlen($data)%4)%4), true) ?: '';
}
function pwa_raw_public_key(array $ec): string {
    return "\x04" . (string)($ec['x']??'') . (string)($ec['y']??'');
}
function ensure_pwa_config(): array {
    ensure_settings_table();
    $pub=get_setting('pwa_vapid_public','');
    $priv=get_setting('pwa_vapid_private_pem','');
    $sub=get_setting('pwa_vapid_subject','');
    if($pub && $priv) return ['public'=>$pub,'private'=>$priv,'subject'=>$sub ?: 'mailto:'.get_setting('invoice_email','admin@example.com')];
    $key=openssl_pkey_new(['private_key_type'=>OPENSSL_KEYTYPE_EC,'curve_name'=>'prime256v1']);
    if(!$key) throw new RuntimeException('Unable to initialize Web Push VAPID keys.');
    $details=openssl_pkey_get_details($key);
    $pem=''; if(!openssl_pkey_export($key,$pem)) throw new RuntimeException('Unable to export Web Push VAPID key.');
    $raw=pwa_raw_public_key($details['ec']??[]);
    if(strlen($raw)!==65) throw new RuntimeException('Invalid VAPID public key.');
    $pub=pwa_base64url($raw);
    $sub=$sub ?: 'mailto:'.get_setting('invoice_email','admin@example.com');
    set_setting('pwa_vapid_public',$pub); set_setting('pwa_vapid_private_pem',$pem); set_setting('pwa_vapid_subject',$sub);
    return ['public'=>$pub,'private'=>$pem,'subject'=>$sub];
}
function pwa_get_subscriptions(): array {
    $raw=get_setting('admin_push_subscriptions','[]'); $data=json_decode($raw,true); return is_array($data)?$data:[];
}
function pwa_save_subscriptions(array $subs): void {
    set_setting('admin_push_subscriptions',json_encode(array_values($subs),JSON_UNESCAPED_SLASHES));
}
function pwa_der_to_raw_signature(string $der): string {
    $len=ord($der[1]); $pos=2; if($len&0x80){$n=$len&0x7f;$len=0;for($i=0;$i<$n;$i++)$len=($len<<8)|ord($der[$pos++]);}
    if(ord($der[$pos++])!==0x30) throw new RuntimeException('Invalid ECDSA signature.');
    $seqLen=ord($der[$pos++]); if($seqLen&0x80){$n=$seqLen&0x7f;$seqLen=0;for($i=0;$i<$n;$i++)$seqLen=($seqLen<<8)|ord($der[$pos++]);}
    if(ord($der[$pos++])!==0x02) throw new RuntimeException('Invalid ECDSA R.'); $rLen=ord($der[$pos++]); $r=substr($der,$pos,$rLen); $pos+=$rLen;
    if(ord($der[$pos++])!==0x02) throw new RuntimeException('Invalid ECDSA S.'); $sLen=ord($der[$pos++]); $s=substr($der,$pos,$sLen);
    $r=ltrim($r,"\0");$s=ltrim($s,"\0"); return str_pad($r,32,"\0",STR_PAD_LEFT).str_pad($s,32,"\0",STR_PAD_LEFT);
}
function pwa_hkdf(string $ikm,string $salt,string $info,int $length): string {
    $prk=hash_hmac('sha256',$ikm,$salt,true); $t='';$okm=''; for($i=1;strlen($okm)<$length;$i++){$t=hash_hmac('sha256',$t.$info.chr($i),$prk,true);$okm.=$t;} return substr($okm,0,$length);
}
function pwa_public_pem_from_raw(string $raw): string {
    if(strlen($raw)!==65 || $raw[0]!=="\x04") throw new RuntimeException('Invalid browser public key.');
    $der=hex2bin('3059301306072a8648ce3d020106082a8648ce3d030107034200').$raw;
    return "-----BEGIN PUBLIC KEY-----\n".chunk_split(base64_encode($der),64,"\n")."-----END PUBLIC KEY-----\n";
}
function pwa_vapid_jwt(string $aud,string $subject,string $privatePem,string $publicRaw): string {
    $head=pwa_base64url(json_encode(['typ'=>'JWT','alg'=>'ES256'])); $payload=pwa_base64url(json_encode(['aud'=>$aud,'exp'=>time()+43200,'sub'=>$subject])); $input=$head.'.'.$payload;
    if(!openssl_sign($input,$der,$privatePem,OPENSSL_ALGO_SHA256)) throw new RuntimeException('Unable to sign VAPID token.');
    return $input.'.'.pwa_base64url(pwa_der_to_raw_signature($der));
}
function pwa_send_web_push(array $subscription,string $title,string $body,string $url=''): bool {
    $endpoint=(string)($subscription['endpoint']??''); $keys=$subscription['keys']??[]; if(!$endpoint||empty($keys['p256dh'])||empty($keys['auth'])) return false;
    $cfg=ensure_pwa_config(); $parts=parse_url($endpoint); if(empty($parts['scheme'])||empty($parts['host'])) return false; $aud=$parts['scheme'].'://'.$parts['host'];
    $clientRaw=pwa_base64url_decode((string)$keys['p256dh']); $auth=pwa_base64url_decode((string)$keys['auth']); if(strlen($clientRaw)!==65||strlen($auth)!==16)return false;
    $ephemeral=openssl_pkey_new(['private_key_type'=>OPENSSL_KEYTYPE_EC,'curve_name'=>'prime256v1']); if(!$ephemeral)return false; $ed=openssl_pkey_get_details($ephemeral); $serverRaw=pwa_raw_public_key($ed['ec']??[]); $clientPem=pwa_public_pem_from_raw($clientRaw);
    $shared=openssl_pkey_derive($clientPem,$ephemeral,32); if($shared===false)return false;
    $keyInfo="WebPush: info\0".$clientRaw.$serverRaw; $ikm=pwa_hkdf($shared,$auth,$keyInfo,32); $salt=random_bytes(16); $cek=pwa_hkdf($ikm,$salt,"Content-Encoding: aes128gcm\0",16); $nonce=pwa_hkdf($ikm,$salt,"Content-Encoding: nonce\0",12);
    $plain=json_encode(['title'=>$title,'body'=>$body,'url'=>$url?:'/admin/'],JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)."\x02"; $tag=''; $cipher=openssl_encrypt($plain,'aes-128-gcm',$cek,OPENSSL_RAW_DATA,$nonce,$tag); if($cipher===false)return false;
    $rs=4096; $payload=$salt.pack('N',$rs).chr(strlen($serverRaw)).$serverRaw.$cipher.$tag; $jwt=pwa_vapid_jwt($aud,$cfg['subject'],$cfg['private'],pwa_base64url_decode($cfg['public']));
    $ch=curl_init($endpoint); curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>$payload,CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=>12,CURLOPT_HTTPHEADER=>['Content-Type: application/octet-stream','Content-Encoding: aes128gcm','TTL: 300','Authorization: vapid t='.$jwt.', k='.$cfg['public']]]); $resp=curl_exec($ch); $code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE); curl_close($ch); return $code>=200&&$code<300;
}
